const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

import { useAuth } from '@/lib/AuthContext';

/**
 * Fetches the current user's profile from the database.
 * 
 * SECURITY: The Base44 SDK automatically scopes all entity queries
 * to the authenticated user via created_by_id. Users can never
 * read or write another user's profile records.
 * 
 * NO staleTime — always fetch fresh data so premium status and
 * credits reflect the live database value immediately.
 */
export function useUserProfile() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  // Admin users automatically get all premium benefits
  const isAdmin = user?.role === 'admin';
  const userId = user?.id || null;

  const { data: profiles, isLoading } = useQuery({
    queryKey: ['userProfile'],
    // Fetch the oldest profile (first created) so returning users always
    // get their original account, not a duplicate created later.
    queryFn: () => db.entities.UserProfile.list('created_date', 1),
    staleTime: 0,
    gcTime: 0,
    retry: 2,
    enabled: !!userId,
  });

  const rawProfile = Array.isArray(profiles) && profiles.length > 0 ? profiles[0] : null;

  // Admins always appear as premium regardless of DB plan field
  const profile = rawProfile && isAdmin
    ? { ...rawProfile, plan: 'premium', credits_remaining: 999999 }
    : rawProfile;

  const createProfile = useMutation({
    mutationFn: (data) => db.entities.UserProfile.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['userProfile'] }),
  });

  const updateProfile = useMutation({
    mutationFn: (data) => {
      if (!profile?.id) throw new Error('No profile to update');
      return db.entities.UserProfile.update(profile.id, data);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['userProfile'] }),
  });

  /**
   * Deducts credits for a generation and updates usage stats.
   * 
   * CRITICAL: Always fetches a FRESH profile directly from the DB
   * before deducting to prevent race conditions and stale-read bugs.
   * Premium users are NEVER deducted — treated as unlimited.
   * 
   * Returns true if the generation is allowed, false if not enough credits.
   */
  const deductCredits = async (amount = 20, statField = null) => {
    if (!profile?.id) return false;

    // Always read a fresh copy from the DB — never trust React state for credits.
    const freshProfiles = await db.entities.UserProfile.list('-created_date', 1);
    const freshProfile = freshProfiles?.[0];

    if (!freshProfile) return false;

    // Premium or Admin = unlimited. Skip all credit deduction logic entirely.
    if (freshProfile.plan === 'premium' || isAdmin) {
      const updates = {
        total_generations: (freshProfile.total_generations || 0) + 1,
      };
      if (statField) updates[statField] = (freshProfile[statField] || 0) + 1;
      await db.entities.UserProfile.update(freshProfile.id, updates);
      queryClient.invalidateQueries({ queryKey: ['userProfile'] });
      return true;
    }

    // Free plan — check live credits
    const currentCredits = freshProfile.credits_remaining ?? 0;
    if (currentCredits < amount) return false;

    const updates = {
      credits_remaining: currentCredits - amount,
      total_generations: (freshProfile.total_generations || 0) + 1,
    };
    if (statField) updates[statField] = (freshProfile[statField] || 0) + 1;

    await db.entities.UserProfile.update(freshProfile.id, updates);
    queryClient.invalidateQueries({ queryKey: ['userProfile'] });
    return true;
  };

  return { profile, isLoading, createProfile, updateProfile, deductCredits, userId };
}