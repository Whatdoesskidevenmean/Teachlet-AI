import { useEffect, useRef } from 'react';
import { useUserProfile } from './useUserProfile';
import { useTheme } from '@/lib/ThemeContext';

/**
 * Initializes a UserProfile for brand-new users exactly ONCE.
 *
 * DUPLICATION PREVENTION:
 * - We add a localStorage flag keyed to the user's auth ID so that
 *   even if the React Query cache is cold on reload, we never create
 *   a second profile for a user who already has one.
 * - The flag is set the FIRST time we see profile.id (either found OR
 *   just created). It is only cleared on logout.
 * - createProfile is guarded by ref + mutation state as a secondary lock.
 */
export function useInitProfile() {
  const { profile, isLoading, createProfile, userId } = useUserProfile();
  const { setThemeValue } = useTheme();
  const hasAttempted = useRef(false);

  useEffect(() => {
    if (isLoading) return;

    if (profile) {
      // Mark this user as "has profile" in localStorage so future cold
      // cache loads never attempt creation.
      if (userId) {
        localStorage.setItem(`profile_exists_${userId}`, '1');
      }
      if (profile.theme) {
        setThemeValue(profile.theme);
      }
      return;
    }

    // profile is null after a confirmed DB fetch.
    // Check localStorage flag — if it's set, this is just a cache miss,
    // NOT a truly new user. Never create here.
    if (userId && localStorage.getItem(`profile_exists_${userId}`)) {
      return;
    }

    // Truly new user — create exactly once.
    if (
      !hasAttempted.current &&
      !createProfile.isPending &&
      !createProfile.isSuccess &&
      !createProfile.isError
    ) {
      hasAttempted.current = true;
      createProfile.mutate({
        username: '',
        plan: 'free',
        credits_remaining: 200,
        total_generations: 0,
        files_uploaded: 0,
        study_guides_generated: 0,
        flashcards_generated: 0,
        practice_tests_generated: 0,
        quizzes_generated: 0,
        summaries_generated: 0,
        projects_generated: 0,
        presentations_generated: 0,
        posters_generated: 0,
        essays_generated: 0,
        ai_tutor_sessions: 0,
        study_hours: 0,
        theme: 'light',
      });
    }
  }, [isLoading, profile?.id, userId]);
}