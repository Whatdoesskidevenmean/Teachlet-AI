import React from 'react';
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function GenerationCard({ icon: Icon, label, desc, onClick, generating, disabled }) {
  return (
    <motion.button
      onClick={onClick}
      disabled={generating || disabled}
      className={cn(
        "text-left p-5 rounded-xl border border-border bg-card hover:border-primary/40 hover:shadow-md hover:shadow-primary/5 transition-all duration-200 group disabled:opacity-50 disabled:cursor-not-allowed"
      )}
      whileHover={!generating && !disabled ? { scale: 1.02 } : {}}
      whileTap={!generating && !disabled ? { scale: 0.98 } : {}}
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
          {generating ? (
            <Loader2 className="w-5 h-5 text-primary animate-spin" />
          ) : (
            <Icon className="w-5 h-5 text-primary" />
          )}
        </div>
        <div>
          <p className="font-heading font-semibold text-sm">{label}</p>
          <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>
        </div>
      </div>
    </motion.button>
  );
}