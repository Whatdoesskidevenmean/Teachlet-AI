import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Plus, Home, FolderOpen, BookOpen, Brain, FileText, HelpCircle,
  FileType, Mic, Image, FileCheck, PenTool, Bot, Calendar,
  Target, BarChart3, Settings, Gem, X
} from "lucide-react";
import Logo from "@/components/Logo";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import ThemeToggle from "@/components/ThemeToggle";

const navItems = [
  { icon: Home, label: "Dashboard", path: "/dashboard" },
  { icon: FolderOpen, label: "My Files", path: "/files" },
  { type: "divider", label: "Study Tools" },
  { icon: BookOpen, label: "Study Guides", path: "/study-guides" },
  { icon: Brain, label: "Flashcards", path: "/flashcards" },
  { icon: FileText, label: "Practice Tests", path: "/practice-tests" },
  { icon: HelpCircle, label: "Quizzes", path: "/quizzes" },
  { icon: FileType, label: "Summaries", path: "/summaries" },
  { icon: Mic, label: "Presentations", path: "/presentations" },
  { icon: Image, label: "Posters", path: "/posters" },
  { icon: FileCheck, label: "Projects", path: "/projects" },
  { icon: PenTool, label: "Essays", path: "/essays" },
  { type: "divider", label: "AI Tools" },
  { icon: Bot, label: "AI Tutor", path: "/ai-tutor" },
  { icon: Calendar, label: "Study Planner", path: "/study-planner" },
  { icon: Target, label: "Exam Prep", path: "/exam-prep" },
  { icon: BarChart3, label: "Analytics", path: "/analytics" },
  { type: "divider" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

export default function Sidebar({ open, onClose }) {
  const location = useLocation();

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={onClose} />
      )}
      
      <aside className={cn(
        "fixed top-0 left-0 h-full w-64 bg-sidebar border-r border-sidebar-border z-50 flex flex-col transition-transform duration-300",
        "lg:translate-x-0",
        open ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Logo */}
        <div className="flex items-center justify-between px-4 h-14 border-b border-sidebar-border flex-shrink-0">
          <Link to="/dashboard" className="flex items-center gap-2">
            <Logo className="w-7 h-7" />
            <span className="font-display font-bold text-sm">Teachlet AI</span>
          </Link>
          <div className="flex items-center gap-1">
            <ThemeToggle className="h-8 w-8" />
            <button className="lg:hidden" onClick={onClose}>
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Insert Files button */}
        <div className="px-3 pt-3 pb-1 flex-shrink-0">
          <Link to="/upload">
            <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl h-10 font-semibold text-sm shadow-md shadow-primary/20">
              <Plus className="w-4 h-4 mr-2" />
              Insert Files
            </Button>
          </Link>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-2 space-y-0.5">
          {navItems.map((item, i) => {
            if (item.type === "divider") {
              return (
                <div key={i} className="pt-4 pb-1">
                  {item.label && (
                    <p className="px-3 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/60">
                      {item.label}
                    </p>
                  )}
                </div>
              );
            }
            const active = location.pathname === item.path;
            return (
              <Link
                key={i}
                to={item.path}
                onClick={onClose}
                className={cn(
                  "flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all duration-150",
                  active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                )}
              >
                <item.icon className={cn("w-4 h-4 flex-shrink-0", active && "text-primary")} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* Upgrade */}
        <div className="p-3 border-t border-sidebar-border flex-shrink-0">
          <Link to="/upgrade">
            <div className="p-3 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 hover:border-primary/40 transition-colors cursor-pointer">
              <div className="flex items-center gap-2">
                <Gem className="w-4 h-4 text-primary" />
                <span className="text-xs font-semibold">Upgrade to Premium</span>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">Unlimited generations & more</p>
            </div>
          </Link>
        </div>
      </aside>
    </>
  );
}