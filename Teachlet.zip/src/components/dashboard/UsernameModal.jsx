const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Loader2, CheckCircle2 } from "lucide-react";

/**
 * Modal that forces new users to pick a username before accessing the dashboard.
 * Checks uniqueness by querying all profiles for the same username.
 */
export default function UsernameModal({ profileId, onSaved }) {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const validate = (val) => {
    if (!val.trim()) return 'Username is required.';
    if (val.length < 3) return 'Username must be at least 3 characters.';
    if (val.length > 24) return 'Username must be 24 characters or less.';
    if (!/^[a-zA-Z0-9_]+$/.test(val)) return 'Only letters, numbers, and underscores allowed.';
    return null;
  };

  const handleSave = async () => {
    const err = validate(username);
    if (err) { setError(err); return; }

    setError('');
    setLoading(true);
    try {
      // Check uniqueness — query all profiles with this username
      const existing = await db.entities.UserProfile.filter({ username: username.trim() });
      // Filter out our own profile to handle re-saves
      const others = existing.filter(p => p.id !== profileId);
      if (others.length > 0) {
        setError('That username is already taken. Please choose another.');
        setLoading(false);
        return;
      }

      await db.entities.UserProfile.update(profileId, { username: username.trim() });
      onSaved(username.trim());
    } catch {
      setError('Failed to save username. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-card border border-border rounded-2xl p-8 w-full max-w-md shadow-2xl">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <User className="w-7 h-7 text-primary" />
          </div>
          <h2 className="text-2xl font-display font-bold">Choose a username</h2>
          <p className="text-sm text-muted-foreground mt-2">
            This is how you'll appear on Teachlet AI. You can change it later in Settings.
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
            {error}
          </div>
        )}

        <div className="space-y-2 mb-6">
          <Label htmlFor="username">Username</Label>
          <Input
            id="username"
            value={username}
            onChange={(e) => { setUsername(e.target.value); setError(''); }}
            placeholder="e.g. studymaster99"
            className="h-12 rounded-xl"
            maxLength={24}
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && handleSave()}
          />
          <p className="text-xs text-muted-foreground">Letters, numbers, and underscores only. 3–24 characters.</p>
        </div>

        <Button
          onClick={handleSave}
          disabled={loading || !username.trim()}
          className="w-full h-12 font-semibold bg-primary text-primary-foreground rounded-xl"
        >
          {loading ? (
            <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
          ) : (
            <><CheckCircle2 className="w-4 h-4 mr-2" /> Continue to Dashboard</>
          )}
        </Button>
      </div>
    </div>
  );
}