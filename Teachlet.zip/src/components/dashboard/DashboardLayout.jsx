import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import { Menu } from "lucide-react";
import ThemeToggle from "@/components/ThemeToggle";
import Logo from "@/components/Logo";
import { Link } from 'react-router-dom';
import { useUserProfile } from '@/hooks/useUserProfile';
import UsernameModal from './UsernameModal';
import { useQueryClient } from '@tanstack/react-query';

export default function DashboardLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { profile, isLoading } = useUserProfile();
  const queryClient = useQueryClient();

  // Show username modal when profile loaded but username not set
  const needsUsername = !isLoading && profile && !profile.username;

  const handleUsernameSaved = () => {
    queryClient.invalidateQueries({ queryKey: ['userProfile'] });
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      {/* Top bar for mobile */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-14 bg-card/80 backdrop-blur-lg border-b border-border z-30 flex items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <button onClick={() => setSidebarOpen(true)}>
            <Menu className="w-5 h-5" />
          </button>
          <Link to="/dashboard" className="flex items-center gap-2">
            <Logo className="w-6 h-6" />
            <span className="font-display font-bold text-sm">Teachlet AI</span>
          </Link>
        </div>
        <ThemeToggle />
      </div>

      {/* Username gate */}
      {needsUsername && (
        <UsernameModal profileId={profile.id} onSaved={handleUsernameSaved} />
      )}

      {/* Main content */}
      <main className="lg:ml-64 pt-14 lg:pt-0 min-h-screen">
        <Outlet />
      </main>
    </div>
  );
}