import React from 'react';
import { cn } from "@/lib/utils";

export default function StatsCard({ icon: Icon, label, value, className }) {
  return (
    <div className={cn(
      "p-4 rounded-xl bg-card border border-border hover:shadow-md transition-shadow",
      className
    )}>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
          <Icon className="w-5 h-5 text-primary" />
        </div>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground truncate">{label}</p>
          <p className="text-lg font-display font-bold">{value}</p>
        </div>
      </div>
    </div>
  );
}