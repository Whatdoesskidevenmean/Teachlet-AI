import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Sparkles, Gem, BookOpen, Brain, FileText, Presentation } from "lucide-react";
import { motion } from "framer-motion";

const floatingCards = [
  { icon: BookOpen, label: "Study Guide", x: -320, y: -60, delay: 0 },
  { icon: Brain, label: "Flashcards", x: 300, y: -80, delay: 0.2 },
  { icon: FileText, label: "Practice Test", x: -280, y: 100, delay: 0.4 },
  { icon: Presentation, label: "Presentation", x: 260, y: 120, delay: 0.6 },
];

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Gradient bg */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-primary/10" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/15 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />

      <div className="relative z-10 max-w-5xl mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4 text-primary" />
            <span>AI-Powered Study Platform</span>
          </div>

          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-display font-bold leading-tight tracking-tight">
            Study Smarter
            <br />
            <span className="text-primary">With AI</span>
          </h1>

          <p className="mt-6 text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Transform notes, PDFs, slides, textbooks, and lectures into study guides, flashcards, practice tests, presentations, and more — in seconds.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/register">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-full px-8 h-12 text-base shadow-lg shadow-primary/25">
                <Sparkles className="w-4 h-4 mr-2" />
                Get Started Free
              </Button>
            </Link>
            <a href="#pricing">
              <Button variant="outline" size="lg" className="rounded-full px-8 h-12 text-base">
                <Gem className="w-4 h-4 mr-2" />
                View Premium
              </Button>
            </a>
          </div>
        </motion.div>

        {/* Floating cards - hidden on mobile */}
        <div className="hidden lg:block">
          {floatingCards.map((card, i) => (
            <motion.div
              key={i}
              className="absolute glass rounded-xl px-4 py-3 flex items-center gap-2 shadow-lg"
              style={{ left: `calc(50% + ${card.x}px)`, top: `calc(50% + ${card.y}px)` }}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1, y: [0, -8, 0] }}
              transition={{
                delay: card.delay + 0.5,
                duration: 0.6,
                y: { duration: 3, repeat: Infinity, ease: "easeInOut", delay: card.delay }
              }}
            >
              <card.icon className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">{card.label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}