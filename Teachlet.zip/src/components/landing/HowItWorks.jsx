import React from 'react';
import { motion } from "framer-motion";
import { Upload, Brain, BookOpen } from "lucide-react";

const steps = [
  { icon: Upload, num: "01", title: "Upload Your Materials", desc: "Drop in PDFs, notes, slides, images, or paste YouTube links and URLs." },
  { icon: Brain, num: "02", title: "AI Analyzes Everything", desc: "Our AI reads and understands your content in seconds." },
  { icon: BookOpen, num: "03", title: "Generate Study Tools", desc: "Create flashcards, study guides, tests, presentations, and more with one click." },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-24 px-4 bg-muted/30">
      <div className="max-w-5xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl font-display font-bold">How It Works</h2>
          <p className="mt-4 text-muted-foreground">Three simple steps to supercharge your studying.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((s, i) => (
            <motion.div
              key={i}
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
            >
              <div className="relative w-16 h-16 mx-auto mb-6">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <s.icon className="w-7 h-7 text-primary" />
                </div>
                <span className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center">
                  {s.num}
                </span>
              </div>
              <h3 className="font-heading font-semibold text-lg">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed max-w-xs mx-auto">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}