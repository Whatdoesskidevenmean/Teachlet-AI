import React from 'react';
import { motion } from "framer-motion";
import { Clock, Zap, TrendingUp, FolderOpen, Rocket, Globe, BookOpen } from "lucide-react";

const benefits = [
  { icon: Clock, title: "Save Hours Every Week", desc: "Generate study materials instantly instead of hours of manual work." },
  { icon: Zap, title: "Instant Generation", desc: "AI creates flashcards, study guides, and tests in seconds." },
  { icon: TrendingUp, title: "Improve Exam Scores", desc: "Targeted practice tests and AI-powered exam prep." },
  { icon: FolderOpen, title: "Stay Organized", desc: "All your materials in one place, linked to your uploads." },
  { icon: Rocket, title: "Learn Faster", desc: "Active recall, spaced repetition, and smart review modes." },
  { icon: Globe, title: "Available 24/7", desc: "Study anytime, anywhere — your AI tutor never sleeps." },
  { icon: BookOpen, title: "Every Subject", desc: "Works for math, science, history, languages, and more." },
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-24 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl font-display font-bold">
            Why <span className="text-primary">Teachlet AI</span>?
          </h2>
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            Everything you need to study smarter, all powered by artificial intelligence.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {benefits.map((b, i) => (
            <motion.div
              key={i}
              className="group relative p-6 rounded-2xl bg-card border border-border hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
            >
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <b.icon className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-heading font-semibold text-lg">{b.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{b.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}