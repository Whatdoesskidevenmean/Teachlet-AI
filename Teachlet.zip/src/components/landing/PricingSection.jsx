import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Check, Sparkles, Star } from "lucide-react";

const plans = [
  {
    name: "Free",
    price: "$0",
    period: "/month",
    desc: "Perfect for getting started",
    popular: false,
    features: [
      "200 Credits Per Month",
      "Unlimited Note Storage",
      "AI Tutor Access",
      "Dashboard & Analytics",
      "All Core Study Tools",
      "20 Credits Per Generation",
    ],
  },
  {
    name: "Premium",
    price: "$6.99",
    period: "/month",
    desc: "For serious students",
    popular: true,
    features: [
      "Unlimited Credits",
      "Unlimited AI Generations",
      "Unlimited File Uploads",
      "Unlimited AI Tutor Conversations",
      "Faster Processing & Priority Servers",
      "No Ads & Premium Themes",
      "AI Exam Predictor",
      "AI Research Assistant",
      "AI Study Planner Pro",
      "Bulk AI Generation",
      "Advanced Analytics",
      "Premium AI Models",
      "100MB Upload Limit",
    ],
  },
];

export default function PricingSection() {
  return (
    <section id="pricing" className="py-24 px-4">
      <div className="max-w-5xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl font-display font-bold">Simple Pricing</h2>
          <p className="mt-4 text-muted-foreground">Start free. Upgrade when you're ready.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {plans.map((plan, i) => (
            <motion.div
              key={i}
              className={`relative rounded-2xl p-8 ${
                plan.popular
                  ? "bg-foreground text-background border-2 border-primary shadow-2xl shadow-primary/20 scale-[1.02]"
                  : "bg-card border border-border"
              }`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center gap-1">
                  <Star className="w-3 h-3" /> Most Popular
                </div>
              )}
              <h3 className="font-heading font-bold text-xl">{plan.name}</h3>
              <p className={`text-sm mt-1 ${plan.popular ? "text-background/60" : "text-muted-foreground"}`}>
                {plan.desc}
              </p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="text-4xl font-display font-bold">{plan.price}</span>
                <span className={`text-sm ${plan.popular ? "text-background/60" : "text-muted-foreground"}`}>
                  {plan.period}
                </span>
              </div>
              <ul className="mt-8 space-y-3">
                {plan.features.map((f, j) => (
                  <li key={j} className="flex items-start gap-2.5 text-sm">
                    <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${plan.popular ? "text-primary" : "text-primary"}`} />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <Link to="/register" className="block mt-8">
                <Button
                  className={`w-full rounded-full h-11 font-semibold ${
                    plan.popular
                      ? "bg-primary text-primary-foreground hover:bg-primary/90"
                      : "bg-foreground text-background hover:bg-foreground/90"
                  }`}
                >
                  {plan.popular && <Sparkles className="w-4 h-4 mr-2" />}
                  {plan.popular ? "Get Premium" : "Start Free"}
                </Button>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}