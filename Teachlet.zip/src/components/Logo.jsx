const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from 'react';

// Graduation cap SVG logo - no background
export default function Logo({ className = "w-8 h-8" }) {
  return (
    <img
      src="https://media.db.com/images/public/6a2b21ee0ba86d4effa54c44/30179014f_ChatGPTImageJun11202601_39_24PM.png"
      alt="Teachlet AI"
      className={className}
      style={{ objectFit: 'contain' }}
    />
  );
}