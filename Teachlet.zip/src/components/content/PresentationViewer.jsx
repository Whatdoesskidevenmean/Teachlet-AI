import React, { useState, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Download, Maximize2, Minimize2 } from "lucide-react";

const layoutStyles = {
  title: { bgClass: 'bg-gradient-to-br from-primary/90 to-primary/60', textClass: 'text-primary-foreground', center: true },
  intro: { bgClass: 'bg-card', textClass: 'text-foreground', center: false },
  content: { bgClass: 'bg-card', textClass: 'text-foreground', center: false },
  summary: { bgClass: 'bg-gradient-to-br from-primary/10 to-primary/5', textClass: 'text-foreground', center: false },
  conclusion: { bgClass: 'bg-gradient-to-br from-foreground/5 to-foreground/10', textClass: 'text-foreground', center: true },
};

export default function PresentationViewer({ slides }) {
  const [current, setCurrent] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const slide = slides[current];
  const layout = layoutStyles[slide?.layout] || layoutStyles.content;
  const total = slides.length;

  const prev = () => setCurrent(c => Math.max(0, c - 1));
  const next = () => setCurrent(c => Math.min(total - 1, c + 1));

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') next();
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') prev();
    if (e.key === 'Escape') setFullscreen(false);
  };

  const handleDownloadPDF = async () => {
    try {
      const { jsPDF } = await import('jspdf');
      const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
      slides.forEach((s, i) => {
        if (i > 0) pdf.addPage();
        pdf.setFillColor(249, 250, 251);
        pdf.rect(0, 0, 297, 210, 'F');
        pdf.setFontSize(22);
        pdf.setTextColor(30, 30, 30);
        pdf.text(s.title || '', 20, 30, { maxWidth: 257 });
        pdf.setFontSize(12);
        pdf.setTextColor(80, 80, 80);
        (s.bullets || []).forEach((b, bi) => {
          pdf.text(`• ${b}`, 20, 55 + bi * 12, { maxWidth: 257 });
        });
      });
      pdf.save('presentation.pdf');
    } catch {
      // jsPDF unavailable
    }
  };

  const SlideContent = ({ s, isFullscreen }) => {
    const sl = layoutStyles[s?.layout] || layoutStyles.content;
    return (
      <div
        className={`${sl.bgClass} rounded-xl border border-border w-full overflow-hidden`}
        style={{ minHeight: isFullscreen ? '70vh' : 340, display: 'flex', flexDirection: 'column' }}
      >
        {/* Slide header */}
        <div className="p-6 pb-3">
          <div className="flex items-start gap-3">
            {s.emoji && <span className="text-3xl flex-shrink-0 mt-0.5">{s.emoji}</span>}
            <div className="flex-1 min-w-0">
              <h2 className={`font-display font-bold ${isFullscreen ? 'text-3xl' : 'text-xl'} ${sl.textClass} leading-tight`}>
                {s.title}
              </h2>
              {s.subtitle && (
                <p className={`mt-1 ${isFullscreen ? 'text-lg' : 'text-sm'} opacity-80 ${sl.textClass}`}>{s.subtitle}</p>
              )}
            </div>
          </div>
        </div>

        {/* Bullets */}
        {s.bullets?.length > 0 && (
          <div className={`px-6 pb-4 flex-1 ${sl.center ? 'flex flex-col justify-center' : ''}`}>
            <ul className="space-y-2.5">
              {s.bullets.map((b, i) => (
                <li key={i} className="flex items-start gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                  <span className={`${isFullscreen ? 'text-base' : 'text-sm'} ${sl.textClass} opacity-90 leading-relaxed`}>{b}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Speaker notes */}
        {s.notes && (
          <div className="mx-4 mb-4 p-3 rounded-lg bg-muted/60 border border-border/50">
            <p className="text-xs text-muted-foreground font-medium mb-0.5">📝 Speaker Notes</p>
            <p className="text-xs text-muted-foreground">{s.notes}</p>
          </div>
        )}

        {/* Slide number */}
        <div className="px-6 py-2 text-xs text-muted-foreground border-t border-border/30 flex justify-between">
          <span>Teachlet AI</span>
          <span>{s.slide_number || current + 1} / {total}</span>
        </div>
      </div>
    );
  };

  return (
    <div
      className={fullscreen ? 'fixed inset-0 z-50 bg-background flex flex-col p-6 overflow-auto' : 'max-w-3xl mx-auto'}
      onKeyDown={handleKeyDown}
      tabIndex={0}
      style={{ outline: 'none' }}
    >
      {/* Controls */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Slide {current + 1} of {total}</span>
          <span className="text-xs bg-muted px-2 py-0.5 rounded-full capitalize">{slide?.layout || 'content'}</span>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="rounded-full" onClick={handleDownloadPDF}>
            <Download className="w-3.5 h-3.5 mr-1" /> PDF
          </Button>
          <Button variant="outline" size="icon" className="rounded-full" onClick={() => setFullscreen(!fullscreen)}>
            {fullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </Button>
        </div>
      </div>

      {/* Slide */}
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
        >
          <SlideContent s={slide} isFullscreen={fullscreen} />
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="flex items-center justify-between mt-4">
        <Button variant="outline" size="sm" disabled={current === 0} onClick={prev} className="rounded-full">
          <ChevronLeft className="w-4 h-4 mr-1" /> Previous
        </Button>

        {/* Dot indicators */}
        <div className="hidden sm:flex gap-1.5">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              className={`w-2 h-2 rounded-full transition-all ${i === current ? 'bg-primary scale-125' : 'bg-muted-foreground/30'}`}
            />
          ))}
        </div>

        <Button variant="outline" size="sm" disabled={current === total - 1} onClick={next} className="rounded-full">
          Next <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>
    </div>
  );
}