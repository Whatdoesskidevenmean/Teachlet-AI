import React, { useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

const themeColors = {
  academic_blue: { bg: '#1a237e', accent: '#3949ab', light: '#e8eaf6', text: '#1a237e' },
  forest_green: { bg: '#1b5e20', accent: '#2e7d32', light: '#e8f5e9', text: '#1b5e20' },
  deep_purple: { bg: '#4a148c', accent: '#6a1b9a', light: '#f3e5f5', text: '#4a148c' },
  modern_gray: { bg: '#212121', accent: '#424242', light: '#f5f5f5', text: '#212121' },
};

export default function PosterViewer({ posterData }) {
  const posterRef = useRef(null);

  const { title, subtitle, sections = [], generated_images = [], color_theme = 'academic_blue' } = posterData;
  const colors = themeColors[color_theme] || themeColors.academic_blue;

  const handleDownload = async () => {
    if (!posterRef.current) return;
    try {
      const { default: html2canvas } = await import('html2canvas');
      const canvas = await html2canvas(posterRef.current, { scale: 2, useCORS: true });
      const link = document.createElement('a');
      link.download = `${title || 'poster'}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch {
      // html2canvas not available
    }
  };

  const handleDownloadPDF = async () => {
    if (!posterRef.current) return;
    try {
      const { default: html2canvas } = await import('html2canvas');
      const { jsPDF } = await import('jspdf');
      const canvas = await html2canvas(posterRef.current, { scale: 2, useCORS: true });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'px', format: [canvas.width / 2, canvas.height / 2] });
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width / 2, canvas.height / 2);
      pdf.save(`${title || 'poster'}.pdf`);
    } catch {
      // jsPDF not available
    }
  };

  return (
    <div className="space-y-4">
      {/* Download buttons */}
      <div className="flex gap-2 flex-wrap">
        <Button variant="outline" size="sm" className="rounded-full" onClick={handleDownload}>
          <Download className="w-3.5 h-3.5 mr-1.5" /> Download PNG
        </Button>
        <Button variant="outline" size="sm" className="rounded-full" onClick={handleDownloadPDF}>
          <Download className="w-3.5 h-3.5 mr-1.5" /> Download PDF
        </Button>
      </div>

      {/* Poster */}
      <div
        ref={posterRef}
        className="rounded-2xl overflow-hidden shadow-2xl"
        style={{ backgroundColor: colors.light, fontFamily: 'Georgia, serif', minWidth: 700 }}
      >
        {/* Header */}
        <div style={{ backgroundColor: colors.bg, color: 'white', padding: '32px 40px' }}>
          <h1 style={{ fontSize: 32, fontWeight: 'bold', marginBottom: 8, lineHeight: 1.2 }}>{title}</h1>
          {subtitle && <p style={{ fontSize: 16, opacity: 0.85 }}>{subtitle}</p>}
        </div>

        {/* Images row */}
        {generated_images.length > 0 && (
          <div style={{ display: 'flex', gap: 16, padding: '20px 40px 0', backgroundColor: colors.light }}>
            {generated_images.map((url, i) => (
              <div key={i} style={{ flex: 1, borderRadius: 12, overflow: 'hidden', border: `2px solid ${colors.accent}` }}>
                <img src={url} alt={`Diagram ${i + 1}`} style={{ width: '100%', height: 200, objectFit: 'cover' }} crossOrigin="anonymous" />
              </div>
            ))}
          </div>
        )}

        {/* Sections grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, padding: 32 }}>
          {sections.map((section, i) => (
            <div
              key={i}
              style={{
                backgroundColor: 'white',
                borderRadius: 12,
                padding: '18px 20px',
                borderLeft: `5px solid ${colors.accent}`,
                boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                ...(i === sections.length - 1 && sections.length % 2 !== 0 ? { gridColumn: 'span 2' } : {})
              }}
            >
              <h3 style={{ fontSize: 15, fontWeight: 'bold', color: colors.text, marginBottom: 10 }}>
                {section.heading}
              </h3>
              {section.type === 'list' && Array.isArray(section.content) ? (
                <ul style={{ paddingLeft: 18, margin: 0 }}>
                  {section.content.map((item, j) => (
                    <li key={j} style={{ fontSize: 13, lineHeight: 1.6, color: '#374151', marginBottom: 4 }}>{item}</li>
                  ))}
                </ul>
              ) : (
                <p style={{ fontSize: 13, lineHeight: 1.7, color: '#374151', margin: 0 }}>
                  {typeof section.content === 'string' ? section.content : JSON.stringify(section.content)}
                </p>
              )}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div style={{ backgroundColor: colors.bg, color: 'white', padding: '12px 40px', fontSize: 12, opacity: 0.9, textAlign: 'center' }}>
          Created with Teachlet AI • Academic Research Poster
        </div>
      </div>
    </div>
  );
}