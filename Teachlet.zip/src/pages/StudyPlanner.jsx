const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { useUserProfile } from '../hooks/useUserProfile';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import ReactMarkdown from 'react-markdown';
import { Calendar, Loader2, Sparkles } from "lucide-react";

export default function StudyPlanner() {
  const [subject, setSubject] = useState('');
  const [examDate, setExamDate] = useState('');
  const [plan, setPlan] = useState('');
  const [loading, setLoading] = useState(false);
  const { deductCredits } = useUserProfile();

  const generate = async () => {
    if (!subject.trim()) return;
    
    const canUse = await deductCredits(20, null);
    if (!canUse) {
      toast({ title: "Not enough credits", variant: "destructive" });
      return;
    }

    setLoading(true);
    const result = await db.integrations.Core.InvokeLLM({
      prompt: `Create a detailed study plan for: ${subject}${examDate ? `. Exam date: ${examDate}` : ''}.

Include:
- Daily study schedule
- Weekly milestones
- Key topics to cover
- Study techniques recommended
- Break schedule
- Review sessions

Format in clear markdown with headers, bullet points, and a structured timeline.`,
    });
    setPlan(result);
    setLoading(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Calendar className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-display font-bold">Study Planner</h1>
          <p className="text-xs text-muted-foreground">Generate a personalized study plan</p>
        </div>
      </div>

      <div className="rounded-xl bg-card border border-border p-5 space-y-4">
        <div>
          <label className="text-xs font-medium mb-1 block">Subject or Topic</label>
          <Input
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="e.g., Biology Chapter 5, AP History, Calculus Finals"
            className="rounded-xl"
          />
        </div>
        <div>
          <label className="text-xs font-medium mb-1 block">Exam Date (optional)</label>
          <Input
            type="date"
            value={examDate}
            onChange={(e) => setExamDate(e.target.value)}
            className="rounded-xl"
          />
        </div>
        <Button
          onClick={generate}
          disabled={!subject.trim() || loading}
          className="bg-primary text-primary-foreground rounded-full font-semibold"
        >
          {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
          Generate Study Plan
        </Button>
      </div>

      {plan && (
        <motion.div
          className="mt-6 rounded-xl bg-card border border-border p-6 prose prose-sm max-w-none"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <ReactMarkdown>{plan}</ReactMarkdown>
        </motion.div>
      )}
    </div>
  );
}