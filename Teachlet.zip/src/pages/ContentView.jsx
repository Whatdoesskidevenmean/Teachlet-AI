const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';

import { Button } from "@/components/ui/button";
import { ArrowLeft, RotateCcw, Shuffle, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";
import ReactMarkdown from 'react-markdown';
import PosterViewer from '@/components/content/PosterViewer';
import PresentationViewer from '@/components/content/PresentationViewer';

function FlashcardViewer({ cards }) {
  const [idx, setIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [shuffled, setShuffled] = useState(cards);

  const shuffle = () => {
    setShuffled([...cards].sort(() => Math.random() - 0.5));
    setIdx(0);
    setFlipped(false);
  };

  const card = shuffled[idx];
  if (!card) return <p className="text-muted-foreground">No flashcards found.</p>;

  return (
    <div className="max-w-lg mx-auto">
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm text-muted-foreground">{idx + 1} / {shuffled.length}</span>
        <Button variant="ghost" size="sm" onClick={shuffle}>
          <Shuffle className="w-4 h-4 mr-1" /> Shuffle
        </Button>
      </div>
      <motion.div
        className="min-h-[240px] rounded-2xl bg-card border border-border p-8 flex items-center justify-center cursor-pointer text-center shadow-sm hover:shadow-md transition-shadow"
        onClick={() => setFlipped(!flipped)}
        key={`${idx}-${flipped}`}
        initial={{ rotateY: 90, opacity: 0 }}
        animate={{ rotateY: 0, opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        <div>
          <p className="text-xs text-muted-foreground mb-2">{flipped ? "Answer" : "Question"}</p>
          <p className="text-lg font-medium">{flipped ? card.back : card.front}</p>
        </div>
      </motion.div>
      <p className="text-xs text-center text-muted-foreground mt-3">Click card to flip</p>
      <div className="flex justify-center gap-3 mt-4">
        <Button variant="outline" size="sm" disabled={idx === 0} onClick={() => { setIdx(idx - 1); setFlipped(false); }}>Previous</Button>
        <Button variant="outline" size="sm" disabled={idx === shuffled.length - 1} onClick={() => { setIdx(idx + 1); setFlipped(false); }}>Next</Button>
      </div>
    </div>
  );
}

function QuizViewer({ questions }) {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const score = submitted
    ? questions.reduce((s, q, i) => s + (answers[i] === q.correct_index ? 1 : 0), 0)
    : 0;

  return (
    <div className="space-y-6 max-w-2xl">
      {questions.map((q, i) => (
        <div key={i} className="p-4 rounded-xl bg-card border border-border">
          <p className="font-medium text-sm mb-3">{i + 1}. {q.question}</p>
          <div className="space-y-2">
            {q.options?.map((opt, j) => {
              const selected = answers[i] === j;
              const correct = submitted && j === q.correct_index;
              const wrong = submitted && selected && j !== q.correct_index;
              return (
                <button
                  key={j}
                  onClick={() => !submitted && setAnswers(prev => ({ ...prev, [i]: j }))}
                  className={`w-full text-left p-3 rounded-lg text-sm border transition-all ${
                    correct ? "border-primary bg-primary/10 text-primary font-medium" :
                    wrong ? "border-destructive bg-destructive/10 text-destructive" :
                    selected ? "border-primary bg-primary/5" :
                    "border-border hover:border-primary/30"
                  }`}
                >
                  {opt}
                </button>
              );
            })}
          </div>
          {submitted && q.explanation && (
            <p className="text-xs text-muted-foreground mt-2 p-2 bg-muted rounded-lg">{q.explanation}</p>
          )}
        </div>
      ))}
      {!submitted ? (
        <Button
          onClick={() => setSubmitted(true)}
          disabled={Object.keys(answers).length < questions.length}
          className="bg-primary text-primary-foreground rounded-full"
        >
          <CheckCircle2 className="w-4 h-4 mr-2" /> Submit Answers
        </Button>
      ) : (
        <div className="p-4 rounded-xl bg-primary/10 border border-primary/20 text-center">
          <p className="font-display font-bold text-xl">{score} / {questions.length}</p>
          <p className="text-sm text-muted-foreground">{score === questions.length ? "Perfect score! 🎉" : "Keep studying!"}</p>
          <Button variant="outline" className="mt-3 rounded-full" onClick={() => { setAnswers({}); setSubmitted(false); }}>
            <RotateCcw className="w-4 h-4 mr-1" /> Retry
          </Button>
        </div>
      )}
    </div>
  );
}

function PracticeTestViewer({ questions }) {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);

  return (
    <div className="space-y-6 max-w-2xl">
      {questions.map((q, i) => (
        <div key={i} className="p-4 rounded-xl bg-card border border-border">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs bg-muted px-2 py-0.5 rounded-full capitalize">{q.type?.replace('_', ' ')}</span>
            <span className="text-xs text-muted-foreground">Q{i + 1}</span>
          </div>
          <p className="font-medium text-sm mb-3">{q.question}</p>

          {q.type === 'multiple_choice' && q.options && (
            <div className="space-y-2">
              {q.options.map((opt, j) => {
                const optLetter = opt.match(/^([A-D])[.):]/)?.[1];
                const selected = answers[i] === j;
                const correct = submitted && (opt === q.answer || optLetter === q.answer);
                const wrong = submitted && selected && !correct;
                return (
                  <button key={j} onClick={() => !submitted && setAnswers(p => ({ ...p, [i]: j }))}
                    className={`w-full text-left p-3 rounded-lg text-sm border transition-all ${
                      correct ? "border-primary bg-primary/10" :
                      wrong ? "border-destructive bg-destructive/10" :
                      selected ? "border-primary bg-primary/5" : "border-border hover:border-primary/30"
                    }`}>
                    {opt}
                  </button>
                );
              })}
            </div>
          )}

          {q.type === 'true_false' && (
            <div className="flex gap-2">
              {['True', 'False'].map((opt) => {
                const selected = answers[i] === opt;
                const correct = submitted && opt === q.answer;
                const wrong = submitted && selected && opt !== q.answer;
                return (
                  <button key={opt} onClick={() => !submitted && setAnswers(p => ({ ...p, [i]: opt }))}
                    className={`px-6 py-2 rounded-lg text-sm border transition-all ${
                      correct ? "border-primary bg-primary/10" :
                      wrong ? "border-destructive bg-destructive/10" :
                      selected ? "border-primary bg-primary/5" : "border-border hover:border-primary/30"
                    }`}>
                    {opt}
                  </button>
                );
              })}
            </div>
          )}

          {q.type === 'short_answer' && (
            <div>
              <textarea
                disabled={submitted}
                value={answers[i] || ''}
                onChange={(e) => !submitted && setAnswers(p => ({ ...p, [i]: e.target.value }))}
                placeholder="Type your answer..."
                className="w-full p-3 rounded-lg border border-border bg-background text-sm resize-none h-24 focus:outline-none focus:ring-1 focus:ring-ring"
              />
            </div>
          )}

          {submitted && q.explanation && (
            <div className="mt-3 p-3 bg-muted rounded-lg">
              <p className="text-xs font-medium mb-1">Answer: {q.answer}</p>
              <p className="text-xs text-muted-foreground">{q.explanation}</p>
            </div>
          )}
        </div>
      ))}

      {!submitted ? (
        <Button onClick={() => setSubmitted(true)} className="bg-primary text-primary-foreground rounded-full">
          <CheckCircle2 className="w-4 h-4 mr-2" /> Submit Test
        </Button>
      ) : (
        <div className="p-4 rounded-xl bg-primary/10 border border-primary/20 text-center">
          <p className="font-display font-bold text-lg">Test Complete!</p>
          <p className="text-sm text-muted-foreground mt-1">Review your answers above.</p>
          <Button variant="outline" className="mt-3 rounded-full" onClick={() => { setAnswers({}); setSubmitted(false); }}>
            <RotateCcw className="w-4 h-4 mr-1" /> Retake
          </Button>
        </div>
      )}
    </div>
  );
}

// Smart parser for AI-generated content
function parseContent(raw, type) {
  if (!raw) return null;

  // Try to extract JSON from the string (AI sometimes wraps it in markdown)
  let jsonStr = raw;
  const jsonMatch = raw.match(/```(?:json)?\s*([\s\S]*?)```/s);
  if (jsonMatch) jsonStr = jsonMatch[1].trim();

  try {
    const parsed = JSON.parse(jsonStr);
    if (type === 'flashcards') return parsed.flashcards || parsed.cards || (Array.isArray(parsed) ? parsed : null);
    if (type === 'quiz') return parsed.questions || (Array.isArray(parsed) ? parsed : null);
    if (type === 'practice_test') return parsed.questions || (Array.isArray(parsed) ? parsed : null);
    if (type === 'presentation') return parsed.slides || (Array.isArray(parsed) ? parsed : null);
    if (type === 'poster') return parsed.poster || null;
    return parsed;
  } catch {
    return null;
  }
}

export default function ContentView() {
  const { contentId } = useParams();

  const { data: content, isLoading: contentLoading } = useQuery({
    queryKey: ['content', contentId],
    queryFn: async () => {
      // SECURITY: Base44 SDK scopes by created_by_id automatically.
      // filter() will only return records belonging to the current user.
      const items = await db.entities.GeneratedContent.filter({ id: contentId });
      return items[0] || null;
    },
  });

  if (contentLoading) {
    return <div className="p-6 text-center mt-20 text-muted-foreground">Loading...</div>;
  }

  if (!content) {
    return (
      <div className="p-6 text-center mt-20">
        <p className="text-lg font-semibold text-destructive">Access Denied</p>
        <p className="text-muted-foreground mt-1">This content does not exist or you do not have permission to view it.</p>
      </div>
    );
  }

  // Unwrap stored content
  let rawText = content.content || '';
  try {
    const outer = JSON.parse(rawText);
    rawText = outer.raw || outer.content || rawText;
  } catch { /* use as-is */ }

  const type = content.type;
  const isFlashcards = type === 'flashcards';
  const isQuiz = type === 'quiz';
  const isPracticeTest = type === 'practice_test';
  const isPresentation = type === 'presentation';
  const isPoster = type === 'poster';

  const flashcards = isFlashcards ? parseContent(rawText, 'flashcards') : null;
  const quizQuestions = isQuiz ? parseContent(rawText, 'quiz') : null;
  const practiceQuestions = isPracticeTest ? parseContent(rawText, 'practice_test') : null;
  const slides = isPresentation ? parseContent(rawText, 'presentation') : null;
  const posterData = isPoster ? parseContent(rawText, 'poster') : null;

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <Link to={`/workspace/${content.file_id}`}>
          <Button variant="ghost" size="icon" className="rounded-full">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-xl font-display font-bold">{content.title}</h1>
          <p className="text-xs text-muted-foreground capitalize">{content.type?.replace(/_/g, ' ')}</p>
        </div>
      </div>

      {isFlashcards && flashcards?.length > 0 ? (
        <FlashcardViewer cards={flashcards} />
      ) : isQuiz && quizQuestions?.length > 0 ? (
        <QuizViewer questions={quizQuestions} />
      ) : isPracticeTest && practiceQuestions?.length > 0 ? (
        <PracticeTestViewer questions={practiceQuestions} />
      ) : isPresentation && slides?.length > 0 ? (
        <PresentationViewer slides={slides} />
      ) : isPoster && posterData ? (
        <PosterViewer posterData={posterData} />
      ) : (
        <div className="prose prose-sm max-w-none dark:prose-invert prose-headings:font-display">
          <ReactMarkdown>{rawText || 'No content available.'}</ReactMarkdown>
        </div>
      )}
    </div>
  );
}