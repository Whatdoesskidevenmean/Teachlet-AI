const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { motion } from "framer-motion";
import { Search, Plus, FileText, MoreVertical, Trash2, FolderOpen, Image, Youtube, Link2 } from "lucide-react";

const typeIcons = {
  pdf: FileText,
  docx: FileText,
  pptx: FileText,
  txt: FileText,
  image: Image,
  youtube: Youtube,
  url: Link2,
  audio: FileText,
};

export default function Files() {
  const [search, setSearch] = useState('');
  const queryClient = useQueryClient();

  const { data: files = [], isLoading } = useQuery({
    queryKey: ['allFiles'],
    queryFn: () => db.entities.UploadedFile.list('-created_date'),
    initialData: [],
  });

  const filtered = files.filter(f =>
    f.name?.toLowerCase().includes(search.toLowerCase())
  );

  const handleDelete = async (id) => {
    await db.entities.UploadedFile.delete(id);
    queryClient.invalidateQueries({ queryKey: ['allFiles'] });
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <h1 className="text-2xl font-display font-bold">My Files</h1>
        <Link to="/upload">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full font-semibold text-sm">
            <Plus className="w-4 h-4 mr-1" /> Upload
          </Button>
        </Link>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search files..."
          className="pl-9 rounded-xl"
        />
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16">
          <FolderOpen className="w-12 h-12 mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-muted-foreground text-sm">
            {search ? "No files match your search" : "No files uploaded yet"}
          </p>
          {!search && (
            <Link to="/upload">
              <Button className="mt-4 rounded-full bg-primary text-primary-foreground text-sm">
                <Plus className="w-4 h-4 mr-1" /> Upload Your First File
              </Button>
            </Link>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((f, i) => {
            const Icon = typeIcons[f.file_type] || FileText;
            return (
              <motion.div
                key={f.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
              >
                <Link to={`/workspace/${f.id}`}>
                  <div className="p-4 rounded-xl bg-card border border-border hover:border-primary/30 hover:shadow-md transition-all group">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Icon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{f.name}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {f.file_type?.toUpperCase()}
                        </p>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.preventDefault()}>
                          <button className="opacity-0 group-hover:opacity-100 transition-opacity p-1">
                            <MoreVertical className="w-4 h-4 text-muted-foreground" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={(e) => { e.preventDefault(); handleDelete(f.id); }}
                          >
                            <Trash2 className="w-4 h-4 mr-2" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}