const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';

import { useUserProfile } from '../hooks/useUserProfile';
import StatsCard from '../components/dashboard/StatsCard';
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import {
  Coins, Zap, Upload, BookOpen, Brain, FileText, HelpCircle,
  FileType, Bot, Plus, ArrowRight, Gem, Crown, Shield
} from "lucide-react";
import { useInitProfile } from '../hooks/useInitProfile';
import { useAuth } from '@/lib/AuthContext';

const recommendations = [
  { text: "Upload your first notes to get started", icon: Upload, link: "/upload" },
  { text: "Generate flashcards from your uploads", icon: Brain, link: "/flashcards" },
  { text: "Create a practice test for your exam", icon: FileText, link: "/practice-tests" },
  { text: "Chat with the AI Tutor about any topic", icon: Bot, link: "/ai-tutor" },
];

export default function Dashboard() {
  useInitProfile();
  const { profile, isLoading: profileLoading } = useUserProfile();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  const { data: files = [] } = useQuery({
    queryKey: ['uploadedFiles'],
    queryFn: () => db.entities.UploadedFile.list('-created_date', 5),
    initialData: [],
  });
  const { data: generations = [] } = useQuery({
    queryKey: ['recentGenerations'],
    queryFn: () => db.entities.GeneratedContent.list('-created_date', 5),
    initialData: [],
  });

  const p = profile || {};

  const isUnlimited = p.plan === 'premium' || isAdmin;
  const stats = [
    { icon: Coins, label: "Credits Remaining", value: isUnlimited ? '∞' : (p.credits_remaining ?? 200) },
    { icon: Zap, label: "AI Generations", value: p.total_generations ?? 0 },
    { icon: Upload, label: "Files Uploaded", value: p.files_uploaded ?? 0 },
    { icon: BookOpen, label: "Study Guides", value: p.study_guides_generated ?? 0 },
    { icon: Brain, label: "Flashcards", value: p.flashcards_generated ?? 0 },
    { icon: FileText, label: "Practice Tests", value: p.practice_tests_generated ?? 0 },
    { icon: HelpCircle, label: "Quizzes", value: p.quizzes_generated ?? 0 },
    { icon: FileType, label: "Summaries", value: p.summaries_generated ?? 0 },
    { icon: Bot, label: "Tutor Sessions", value: p.ai_tutor_sessions ?? 0 },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold">Dashboard</h1>
          <div className="flex items-center gap-2 mt-1">
            {isAdmin ? (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-blue-500/10 text-blue-600 dark:text-blue-400 px-2.5 py-1 rounded-full border border-blue-500/20">
                <Shield className="w-3 h-3" /> Admin — Unlimited Access
              </span>
            ) : p.plan === 'premium' ? (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold bg-primary/10 text-primary px-2.5 py-1 rounded-full border border-primary/20">
                <Crown className="w-3 h-3" /> Premium Plan — Unlimited Access
              </span>
            ) : (
              <span className="text-sm text-muted-foreground">Free Plan · {p.credits_remaining ?? 200} credits remaining</span>
            )}
          </div>
        </div>
        <div className="flex gap-2">
          {p.plan !== 'premium' && (
            <Link to="/upgrade">
              <Button variant="outline" className="rounded-full text-sm border-primary/30 text-primary hover:bg-primary/5">
                <Gem className="w-3.5 h-3.5 mr-1.5" /> Upgrade
              </Button>
            </Link>
          )}
          <Link to="/upload">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full font-semibold shadow-md shadow-primary/20">
              <Plus className="w-4 h-4 mr-2" />
              Insert Files
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <motion.div
        className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {stats.map((s, i) => (
          <StatsCard key={i} icon={s.icon} label={s.label} value={s.value} />
        ))}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        {/* Recent Uploads */}
        <motion.div
          className="rounded-xl bg-card border border-border p-5"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-heading font-semibold">Recent Uploads</h2>
            <Link to="/files" className="text-xs text-primary hover:underline">View all</Link>
          </div>
          {files.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">
              <Upload className="w-8 h-8 mx-auto mb-2 opacity-30" />
              No files uploaded yet
            </div>
          ) : (
            <div className="space-y-2">
              {files.map((f) => (
                <Link key={f.id} to={`/workspace/${f.id}`} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <FileType className="w-4 h-4 text-primary" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{f.name}</p>
                    <p className="text-xs text-muted-foreground">{f.file_type?.toUpperCase()}</p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </motion.div>

        {/* Recommendations */}
        <motion.div
          className="rounded-xl bg-card border border-border p-5"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h2 className="font-heading font-semibold mb-4">Recommended For You</h2>
          <div className="space-y-2">
            {recommendations.map((r, i) => (
              <Link key={i} to={r.link} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors group">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <r.icon className="w-4 h-4 text-primary" />
                </div>
                <p className="text-sm flex-1">{r.text}</p>
                <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
              </Link>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}