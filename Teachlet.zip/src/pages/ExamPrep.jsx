const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { useUserProfile } from '../hooks/useUserProfile';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import ReactMarkdown from 'react-markdown';
import { Target, Loader2, Sparkles } from "lucide-react";

export default function ExamPrep() {
  const [subject, setSubject] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const { deductCredits } = useUserProfile();

  const generate = async () => {
    if (!subject.trim()) return;

    const canUse = await deductCredits(20, null);
    if (!canUse) {
      toast({ title: "Not enough credits", variant: "destructive" });
      return;
    }

    setLoading(true);
    const res = await db.integrations.Core.InvokeLLM({
      prompt: `Act as an exam preparation expert for: ${subject}

Generate:
1. **Likely Exam Questions** - 10 questions that are most likely to appear on an exam
2. **High Priority Topics** - The most important topics to study, ranked
3. **Key Concepts to Master** - Core concepts that must be understood
4. **Common Mistakes to Avoid** - Pitfalls students typically fall into
5. **Last-Minute Review Tips** - Quick strategies for final review

Format in clear, well-organized markdown.`,
    });
    setResult(res);
    setLoading(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Target className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-display font-bold">Exam Prep</h1>
          <p className="text-xs text-muted-foreground">AI-powered exam preparation</p>
        </div>
      </div>

      <div className="rounded-xl bg-card border border-border p-5 space-y-4">
        <div>
          <label className="text-xs font-medium mb-1 block">What are you preparing for?</label>
          <Input
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="e.g., AP Biology Exam, SAT Math, History Final"
            className="rounded-xl"
          />
        </div>
        <Button
          onClick={generate}
          disabled={!subject.trim() || loading}
          className="bg-primary text-primary-foreground rounded-full font-semibold"
        >
          {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
          Generate Exam Prep
        </Button>
      </div>

      {result && (
        <motion.div
          className="mt-6 rounded-xl bg-card border border-border p-6 prose prose-sm max-w-none"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <ReactMarkdown>{result}</ReactMarkdown>
        </motion.div>
      )}
    </div>
  );
}