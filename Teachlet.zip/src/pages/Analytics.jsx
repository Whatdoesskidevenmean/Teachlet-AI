import React from 'react';
import { useUserProfile } from '../hooks/useUserProfile';
import StatsCard from '../components/dashboard/StatsCard';
import { motion } from "framer-motion";
import {
  Coins, Zap, Upload, BookOpen, Brain, FileText, HelpCircle,
  FileType, Mic, Image, FileCheck, PenTool, Bot, Clock, BarChart3
} from "lucide-react";

export default function Analytics() {
  const { profile } = useUserProfile();
  const p = profile || {};

  const allStats = [
    { icon: Coins, label: "Credits Remaining", value: p.plan === 'premium' ? '∞' : (p.credits_remaining ?? 200) },
    { icon: Zap, label: "Total AI Generations", value: p.total_generations ?? 0 },
    { icon: Upload, label: "Files Uploaded", value: p.files_uploaded ?? 0 },
    { icon: BookOpen, label: "Study Guides", value: p.study_guides_generated ?? 0 },
    { icon: Brain, label: "Flashcards Sets", value: p.flashcards_generated ?? 0 },
    { icon: FileText, label: "Practice Tests", value: p.practice_tests_generated ?? 0 },
    { icon: HelpCircle, label: "Quizzes", value: p.quizzes_generated ?? 0 },
    { icon: FileType, label: "Summaries", value: p.summaries_generated ?? 0 },
    { icon: FileCheck, label: "Projects", value: p.projects_generated ?? 0 },
    { icon: Mic, label: "Presentations", value: p.presentations_generated ?? 0 },
    { icon: Image, label: "Posters", value: p.posters_generated ?? 0 },
    { icon: PenTool, label: "Essays", value: p.essays_generated ?? 0 },
    { icon: Bot, label: "AI Tutor Sessions", value: p.ai_tutor_sessions ?? 0 },
    { icon: Clock, label: "Study Hours", value: p.study_hours ?? 0 },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <BarChart3 className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-display font-bold">Analytics</h1>
          <p className="text-xs text-muted-foreground">Track your study statistics</p>
        </div>
      </div>

      <motion.div
        className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {allStats.map((s, i) => (
          <StatsCard key={i} icon={s.icon} label={s.label} value={s.value} />
        ))}
      </motion.div>
    </div>
  );
}