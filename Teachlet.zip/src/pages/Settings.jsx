const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import { useUserProfile } from '../hooks/useUserProfile';
import { useAuth } from '@/lib/AuthContext';
import { useTheme } from '@/lib/ThemeContext';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Settings as SettingsIcon, User, Gem, Save, LogOut,
  Moon, Sun, CreditCard, AlertTriangle, CheckCircle2,
  RefreshCw, ExternalLink
} from "lucide-react";
import { Link } from 'react-router-dom';
import { motion } from "framer-motion";

const PLAN_LABELS = {
  none: 'No active subscription',
  active: 'Active',
  trialing: 'Trial',
  canceled: 'Canceled',
  past_due: 'Past Due',
};

const PLAN_COLORS = {
  active: 'text-green-600',
  trialing: 'text-blue-600',
  canceled: 'text-muted-foreground',
  past_due: 'text-destructive',
  none: 'text-muted-foreground',
};

export default function Settings() {
  const { profile, isLoading, updateProfile, createProfile } = useUserProfile();
  const { user, logout } = useAuth();
  const { theme, toggleTheme, setThemeValue } = useTheme();
  const [username, setUsername] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (profile?.username) setUsername(profile.username);
    // Sync theme from profile when loaded
    if (profile?.theme && profile.theme !== theme) {
      setThemeValue(profile.theme);
    }
  }, [profile?.id]);

  const handleSaveProfile = async () => {
    if (!username.trim()) { toast.error("Username cannot be empty."); return; }
    if (username.trim().length < 3) { toast.error("Username must be at least 3 characters."); return; }
    if (!/^[a-zA-Z0-9_]+$/.test(username.trim())) { toast.error("Only letters, numbers, and underscores allowed."); return; }
    setSaving(true);
    try {
      // Check uniqueness — exclude own profile
      const existing = await db.entities.UserProfile.filter({ username: username.trim() });
      const others = existing.filter(p => p.id !== profile?.id);
      if (others.length > 0) {
        toast.error("That username is already taken. Please choose another.");
        setSaving(false);
        return;
      }
      if (profile) {
        await updateProfile.mutateAsync({ username: username.trim() });
      } else {
        await createProfile.mutateAsync({ username: username.trim(), credits_remaining: 200, plan: 'free' });
      }
      toast.success("Profile saved");
    } catch {
      toast.error("Failed to save profile");
    } finally {
      setSaving(false);
    }
  };

  const handleToggleTheme = async () => {
    toggleTheme();
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    if (profile) {
      try {
        await updateProfile.mutateAsync({ theme: newTheme });
      } catch {
        // non-critical, localStorage already updated
      }
    }
  };

  const isPremium = profile?.plan === 'premium';
  const subStatus = profile?.subscription_status || 'none';
  const periodEnd = profile?.subscription_current_period_end;

  const formatDate = (dateStr) => {
    if (!dateStr) return null;
    try {
      return new Date(dateStr).toLocaleDateString('en-US', {
        year: 'numeric', month: 'long', day: 'numeric'
      });
    } catch {
      return null;
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <SettingsIcon className="w-5 h-5 text-primary" />
        </div>
        <h1 className="text-2xl font-display font-bold">Settings</h1>
      </div>

      <div className="space-y-5">
        {/* Account Info */}
        <motion.div
          className="rounded-xl bg-card border border-border p-5"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <User className="w-4 h-4 text-primary" />
            <h2 className="font-heading font-semibold">Account</h2>
          </div>

          {user && (
            <p className="text-sm text-muted-foreground mb-4">
              Signed in as <span className="font-medium text-foreground">{user.email}</span>
            </p>
          )}

          <div className="space-y-3">
            <div>
              <Label className="text-xs">Display Name</Label>
              <Input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your display name"
                className="mt-1 rounded-xl"
              />
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleSaveProfile}
                disabled={saving}
                className="bg-primary text-primary-foreground rounded-full text-sm"
              >
                {saving ? <RefreshCw className="w-4 h-4 mr-1 animate-spin" /> : <Save className="w-4 h-4 mr-1" />}
                Save
              </Button>
              <Button
                variant="outline"
                className="rounded-full text-sm text-destructive border-destructive/30 hover:bg-destructive/10"
                onClick={() => logout()}
              >
                <LogOut className="w-4 h-4 mr-1" />
                Sign Out
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Appearance */}
        <motion.div
          className="rounded-xl bg-card border border-border p-5"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
        >
          <div className="flex items-center gap-2 mb-4">
            {theme === 'dark' ? <Moon className="w-4 h-4 text-primary" /> : <Sun className="w-4 h-4 text-primary" />}
            <h2 className="font-heading font-semibold">Appearance</h2>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium">{theme === 'dark' ? 'Dark' : 'Light'} Mode</p>
              <p className="text-xs text-muted-foreground mt-0.5">Saved to your account and synced across devices</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleToggleTheme}
              className="rounded-full"
            >
              {theme === 'dark' ? (
                <><Sun className="w-4 h-4 mr-1" /> Light</>
              ) : (
                <><Moon className="w-4 h-4 mr-1" /> Dark</>
              )}
            </Button>
          </div>
        </motion.div>

        {/* Plan & Credits */}
        <motion.div
          className="rounded-xl bg-card border border-border p-5"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Gem className="w-4 h-4 text-primary" />
            <h2 className="font-heading font-semibold">Plan & Credits</h2>
          </div>

          <div className="flex items-center justify-between">
            <div>
              {isPremium ? (
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 text-sm font-semibold bg-primary/10 text-primary px-3 py-1 rounded-full border border-primary/20">
                    <Gem className="w-3.5 h-3.5" /> Premium Plan
                  </span>
                </div>
              ) : (
                <p className="font-medium">Free Plan</p>
              )}
              <p className="text-xs text-muted-foreground mt-1.5">
                {isPremium
                  ? '✓ Unlimited credits & all features unlocked'
                  : `${profile?.credits_remaining ?? 200} credits remaining`}
              </p>
            </div>
            {!isPremium && (
              <Link to="/upgrade">
                <Button size="sm" className="rounded-full text-sm bg-primary text-primary-foreground">
                  <Gem className="w-4 h-4 mr-1" /> Upgrade
                </Button>
              </Link>
            )}
            {isPremium && (
              <span className="text-xs text-primary font-medium bg-primary/5 px-2 py-1 rounded-full border border-primary/20">
                Current Plan
              </span>
            )}
          </div>
        </motion.div>

        {/* Subscription Management */}
        {isPremium && (
          <motion.div
            className="rounded-xl bg-card border border-border p-5"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
          >
            <div className="flex items-center gap-2 mb-4">
              <CreditCard className="w-4 h-4 text-primary" />
              <h2 className="font-heading font-semibold">Subscription</h2>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between py-2 border-b border-border">
                <span className="text-sm text-muted-foreground">Status</span>
                <span className={`text-sm font-medium ${PLAN_COLORS[subStatus]}`}>
                  {subStatus === 'active' && <CheckCircle2 className="w-3.5 h-3.5 inline mr-1" />}
                  {subStatus === 'past_due' && <AlertTriangle className="w-3.5 h-3.5 inline mr-1" />}
                  {PLAN_LABELS[subStatus] || subStatus}
                </span>
              </div>

              {periodEnd && (
                <div className="flex items-center justify-between py-2 border-b border-border">
                  <span className="text-sm text-muted-foreground">
                    {subStatus === 'canceled' ? 'Access Until' : 'Next Renewal'}
                  </span>
                  <span className="text-sm font-medium">{formatDate(periodEnd)}</span>
                </div>
              )}

              <div className="pt-2">
                <p className="text-xs text-muted-foreground mb-3">
                  Manage your billing, update payment details, or cancel your subscription via the Stripe customer portal.
                </p>
                <Link to="/upgrade">
                  <Button variant="outline" size="sm" className="rounded-full text-sm">
                    <ExternalLink className="w-4 h-4 mr-1" />
                    Manage Subscription
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        )}

        {/* Danger Zone */}
        <motion.div
          className="rounded-xl bg-card border border-destructive/20 p-5"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-destructive" />
            <h2 className="font-heading font-semibold text-destructive">Account</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-3">Sign out from all devices.</p>
          <Button
            variant="outline"
            size="sm"
            className="rounded-full text-sm text-destructive border-destructive/30 hover:bg-destructive/10"
            onClick={() => logout()}
          >
            <LogOut className="w-4 h-4 mr-1" />
            Sign Out
          </Button>
        </motion.div>
      </div>
    </div>
  );
}