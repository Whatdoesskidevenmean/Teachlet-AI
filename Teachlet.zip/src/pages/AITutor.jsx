const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useRef, useEffect } from 'react';

import { useUserProfile } from '../hooks/useUserProfile';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import ReactMarkdown from 'react-markdown';
import { Bot, Send, Loader2, Sparkles, Trash2 } from "lucide-react";

export default function AITutor() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: "Hi! I'm your AI Tutor. Ask me anything about your studies — I can explain concepts, create examples, generate analogies, and help you understand tricky topics. What would you like to learn about?" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);
  const { profile, deductCredits } = useUserProfile();

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const send = async () => {
    if (!input.trim() || loading) return;

    // Daily limit check for free users (5 messages per day)
    const isUnlimited = profile?.plan === 'premium' || profile?._isAdmin;
    if (!isUnlimited) {
      const today = new Date().toDateString();
      const stored = JSON.parse(localStorage.getItem('tutor_daily') || '{"date":"","count":0}');
      const count = stored.date === today ? stored.count : 0;
      if (count >= 5) {
        setMessages(prev => [...prev, { role: 'assistant', content: "You've reached your **5 daily message limit** for free users. [Upgrade to Premium](/upgrade) for unlimited AI Tutor conversations!" }]);
        return;
      }
      localStorage.setItem('tutor_daily', JSON.stringify({ date: today, count: count + 1 }));
    }

    const userMsg = { role: 'user', content: input.trim() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    const canUse = await deductCredits(20, 'ai_tutor_sessions');
    if (!canUse) {
      setMessages(prev => [...prev, { role: 'assistant', content: "You've run out of credits. Upgrade to Premium for unlimited AI Tutor conversations!" }]);
      setLoading(false);
      return;
    }

    const history = messages.slice(-10).map(m => `${m.role}: ${m.content}`).join('\n');

    const result = await db.integrations.Core.InvokeLLM({
      prompt: `You are an expert AI tutor. Be helpful, clear, and educational. Use examples and analogies. Format responses in markdown.

Previous conversation:
${history}

Student's question: ${userMsg.content}

Provide a thorough, well-structured answer.`,
    });

    setMessages(prev => [...prev, { role: 'assistant', content: result }]);
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-56px)] lg:h-screen">
      {/* Header */}
      <div className="flex items-center justify-between px-4 sm:px-6 h-14 border-b border-border flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Bot className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h1 className="text-sm font-display font-bold">AI Tutor</h1>
            <p className="text-[10px] text-muted-foreground">Ask anything about your studies</p>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setMessages([messages[0]])}>
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.map((msg, i) => (
          <motion.div
            key={i}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className={`max-w-[85%] sm:max-w-[70%] rounded-2xl px-4 py-3 ${
              msg.role === 'user'
                ? 'bg-primary text-primary-foreground'
                : 'bg-card border border-border'
            }`}>
              {msg.role === 'user' ? (
                <p className="text-sm">{msg.content}</p>
              ) : (
                <div className="prose prose-sm max-w-none text-sm">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>
              )}
            </div>
          </motion.div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-card border border-border rounded-2xl px-4 py-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" />
                Thinking...
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-border p-4 flex-shrink-0">
        <div className="max-w-3xl mx-auto flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && send()}
            placeholder="Ask your AI Tutor anything..."
            className="rounded-xl"
            disabled={loading}
          />
          <Button
            onClick={send}
            disabled={!input.trim() || loading}
            className="bg-primary text-primary-foreground rounded-xl px-4"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}