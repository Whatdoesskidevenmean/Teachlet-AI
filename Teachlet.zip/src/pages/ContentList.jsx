const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';

import { motion } from "framer-motion";
import { 
  BookOpen, Brain, FileText, HelpCircle, FileType, 
  Mic, Image, FileCheck, PenTool, Sparkles, Plus 
} from "lucide-react";
import { Button } from "@/components/ui/button";

const typeConfig = {
  '/study-guides': { type: 'study_guide', label: 'Study Guides', icon: BookOpen },
  '/flashcards': { type: 'flashcards', label: 'Flashcards', icon: Brain },
  '/practice-tests': { type: 'practice_test', label: 'Practice Tests', icon: FileText },
  '/quizzes': { type: 'quiz', label: 'Quizzes', icon: HelpCircle },
  '/summaries': { type: 'summary', label: 'Summaries', icon: FileType },
  '/presentations': { type: 'presentation', label: 'Presentations', icon: Mic },
  '/posters': { type: 'poster', label: 'Posters', icon: Image },
  '/projects': { type: 'project', label: 'Projects', icon: FileCheck },
  '/essays': { type: 'essay', label: 'Essays', icon: PenTool },
};

export default function ContentList() {
  const location = useLocation();
  const config = typeConfig[location.pathname] || { type: 'study_guide', label: 'Content', icon: Sparkles };
  const Icon = config.icon;

  const { data: items = [] } = useQuery({
    queryKey: ['contentList', config.type],
    queryFn: () => db.entities.GeneratedContent.filter({ type: config.type }, '-created_date'),
    initialData: [],
  });

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Icon className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-display font-bold">{config.label}</h1>
            <p className="text-xs text-muted-foreground">{items.length} item{items.length !== 1 ? 's' : ''}</p>
          </div>
        </div>
        <Link to="/upload">
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full text-sm">
            <Plus className="w-4 h-4 mr-1" /> Create New
          </Button>
        </Link>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-16">
          <Icon className="w-12 h-12 mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-muted-foreground text-sm">No {config.label.toLowerCase()} yet</p>
          <p className="text-xs text-muted-foreground mt-1">Upload a file and generate your first one</p>
          <Link to="/upload">
            <Button className="mt-4 rounded-full bg-primary text-primary-foreground text-sm">
              Get Started
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {items.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
            >
              <Link to={`/view/${item.id}`}>
                <div className="p-4 rounded-xl bg-card border border-border hover:border-primary/30 hover:shadow-md transition-all">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-4 h-4 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{item.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(item.created_date).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}