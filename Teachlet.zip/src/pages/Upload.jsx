const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';

import { useQueryClient } from '@tanstack/react-query';
import { useUserProfile } from '../hooks/useUserProfile';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, FileText, Image, Link2, Youtube, Loader2, CheckCircle2, X, Sparkles } from "lucide-react";

const FREE_DAILY_LIMIT = 5;

export default function UploadPage() {
  const [files, setFiles] = useState([]);
  const [urlInput, setUrlInput] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadedIds, setUploadedIds] = useState([]);
  const [limitError, setLimitError] = useState('');
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { profile } = useUserProfile();
  const isPremium = profile?.plan === 'premium';

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer?.files || []);
    setFiles(prev => [...prev, ...dropped]);
  }, []);

  const handleFileSelect = (e) => {
    const selected = Array.from(e.target.files || []);
    setFiles(prev => [...prev, ...selected]);
  };

  const removeFile = (idx) => {
    setFiles(prev => prev.filter((_, i) => i !== idx));
  };

  const addUrl = () => {
    if (!urlInput.trim()) return;
    const isYoutube = urlInput.includes('youtube.com') || urlInput.includes('youtu.be');
    setFiles(prev => [...prev, { name: urlInput, isUrl: true, type: isYoutube ? 'youtube' : 'url' }]);
    setUrlInput('');
  };

  const getFileType = (file) => {
    if (file.isUrl) return file.type;
    const ext = file.name.split('.').pop().toLowerCase();
    if (['pdf'].includes(ext)) return 'pdf';
    if (['docx', 'doc'].includes(ext)) return 'docx';
    if (['pptx', 'ppt'].includes(ext)) return 'pptx';
    if (['txt'].includes(ext)) return 'txt';
    if (['png', 'jpg', 'jpeg', 'webp'].includes(ext)) return 'image';
    if (['mp3', 'wav', 'ogg', 'm4a'].includes(ext)) return 'audio';
    return 'txt';
  };

  const handleUpload = async () => {
    if (files.length === 0) return;
    setLimitError('');

    // Enforce 5 uploads/day for free users
    if (!isPremium) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const allFiles = await db.entities.UploadedFile.list('-created_date', 20);
      const todayUploads = allFiles.filter(f => new Date(f.created_date) >= today);
      if (todayUploads.length + files.length > FREE_DAILY_LIMIT) {
        setLimitError(`Free users can upload up to ${FREE_DAILY_LIMIT} files per day. You've used ${todayUploads.length} today. Upgrade to Premium for unlimited uploads.`);
        return;
      }
    }

    setUploading(true);
    const ids = [];

    for (const file of files) {
      const fileType = getFileType(file);
      let fileUrl = '';

      if (!file.isUrl) {
        const result = await db.integrations.Core.UploadFile({ file });
        fileUrl = result.file_url;
      } else {
        fileUrl = file.name;
      }

      const record = await db.entities.UploadedFile.create({
        name: file.isUrl ? file.name : file.name,
        file_url: fileUrl,
        file_type: fileType,
        status: 'ready',
        size_bytes: file.size || 0,
      });
      ids.push(record.id);
    }

    // Always read a fresh profile from DB before updating counters —
    // never use React state which may be stale.
    const freshProfiles = await db.entities.UserProfile.list('-created_date', 1);
    const freshProfile = freshProfiles?.[0];
    if (freshProfile) {
      await db.entities.UserProfile.update(freshProfile.id, {
        files_uploaded: (freshProfile.files_uploaded || 0) + files.length,
      });
    }

    queryClient.invalidateQueries({ queryKey: ['uploadedFiles'] });
    queryClient.invalidateQueries({ queryKey: ['userProfile'] });
    setUploadedIds(ids);
    setUploading(false);

    // Navigate to workspace of first file
    if (ids.length === 1) {
      navigate(`/workspace/${ids[0]}`);
    }
  };

  const fileTypeIcon = (file) => {
    const type = getFileType(file);
    if (type === 'youtube') return <Youtube className="w-4 h-4 text-red-500" />;
    if (type === 'url') return <Link2 className="w-4 h-4 text-blue-500" />;
    if (type === 'image') return <Image className="w-4 h-4 text-purple-500" />;
    return <FileText className="w-4 h-4 text-primary" />;
  };

  if (uploadedIds.length > 1) {
    return (
      <div className="p-6 max-w-2xl mx-auto text-center mt-20">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
          <CheckCircle2 className="w-16 h-16 text-primary mx-auto mb-4" />
          <h2 className="text-2xl font-display font-bold">Files Uploaded!</h2>
          <p className="text-muted-foreground mt-2">{uploadedIds.length} files are ready. Choose one to start generating.</p>
          <Button onClick={() => navigate('/files')} className="mt-6 rounded-full bg-primary text-primary-foreground">
            Go to My Files
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-3xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-display font-bold">Insert Files</h1>
        <p className="text-sm text-muted-foreground mt-1">Upload your study materials to get started</p>
      </div>

      {/* Daily limit error */}
      {limitError && (
        <div className="mb-4 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm">
          {limitError}
          <div className="mt-2">
            <Link to="/upgrade" className="font-semibold underline hover:opacity-80">Upgrade to Premium →</Link>
          </div>
        </div>
      )}

      {/* Drop Zone */}
      <motion.div
        className="border-2 border-dashed border-border rounded-2xl p-8 sm:p-12 text-center hover:border-primary/50 transition-colors cursor-pointer relative"
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        onClick={() => document.getElementById('file-input').click()}
        whileHover={{ scale: 1.005 }}
      >
        <input
          id="file-input"
          type="file"
          multiple
          accept=".pdf,.docx,.pptx,.txt,.png,.jpg,.jpeg,.webp,.mp3,.wav,.ogg,.m4a"
          className="hidden"
          onChange={handleFileSelect}
        />
        <Upload className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
        <p className="font-medium">Drop files here or click to browse</p>
        <p className="text-xs text-muted-foreground mt-2">
          PDF, DOCX, PPTX, TXT, Images, Audio — up to 25MB
        </p>
      </motion.div>

      {/* URL Input */}
      <div className="flex gap-2 mt-4">
        <Input
          placeholder="Paste a YouTube link or website URL..."
          value={urlInput}
          onChange={(e) => setUrlInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && addUrl()}
          className="rounded-xl"
        />
        <Button variant="outline" onClick={addUrl} className="rounded-xl flex-shrink-0">
          <Link2 className="w-4 h-4 mr-1" /> Add
        </Button>
      </div>

      {/* File List */}
      <AnimatePresence>
        {files.length > 0 && (
          <motion.div
            className="mt-6 space-y-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {files.map((file, i) => (
              <motion.div
                key={i}
                className="flex items-center gap-3 p-3 rounded-xl bg-card border border-border"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
              >
                {fileTypeIcon(file)}
                <span className="text-sm flex-1 truncate">{file.name}</span>
                <span className="text-xs text-muted-foreground">
                  {file.size ? `${(file.size / 1024).toFixed(0)} KB` : getFileType(file).toUpperCase()}
                </span>
                <button onClick={() => removeFile(i)} className="text-muted-foreground hover:text-destructive">
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            ))}

            <Button
              onClick={handleUpload}
              disabled={uploading}
              className="w-full mt-4 bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl h-11 font-semibold shadow-md shadow-primary/20"
            >
              {uploading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Upload & Analyze ({files.length} file{files.length > 1 ? 's' : ''})
                </>
              )}
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}