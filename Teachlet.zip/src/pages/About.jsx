import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, GraduationCap, Sparkles, Users, Target } from 'lucide-react';

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-4 py-12 sm:py-16">
        <Link to="/">
          <Button variant="ghost" size="sm" className="mb-8">
            <ArrowLeft className="w-4 h-4 mr-1" /> Back to Home
          </Button>
        </Link>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
            <GraduationCap className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-display font-bold">About Teachlet</h1>
        </div>

        <div className="prose prose-neutral dark:prose-invert max-w-none space-y-6 text-foreground/80 leading-relaxed">

          <p className="text-lg text-foreground font-medium">
            Teachlet is an AI-powered learning platform that transforms the way students study, prepare, and succeed.
          </p>

          <div className="rounded-xl border border-border bg-card p-6 space-y-3">
            <div className="flex items-center gap-2 font-heading font-semibold text-foreground">
              <Sparkles className="w-4 h-4 text-primary" /> What Teachlet Does
            </div>
            <p>
              Teachlet lets you upload any study material — PDF notes, Word documents, PowerPoint slides, audio recordings, images, or even YouTube video links — and instantly converts them into powerful, interactive study tools. In seconds, our AI generates personalised study guides, flashcard decks, practice tests, quizzes, summaries, essays, presentations, posters, and mind maps tailored to your exact content. No more hours spent manually creating revision materials. Just upload, and let Teachlet do the heavy lifting.
            </p>
          </div>

          <div className="rounded-xl border border-border bg-card p-6 space-y-3">
            <div className="flex items-center gap-2 font-heading font-semibold text-foreground">
              <Users className="w-4 h-4 text-primary" /> Who It's For
            </div>
            <p>
              Teachlet is built for students of all ages and levels — from middle school and high school students preparing for exams, to university undergraduates juggling multiple subjects, to graduate students conducting in-depth research. Whether you're cramming for finals, reviewing a semester's worth of notes, or trying to deeply understand a single complex topic, Teachlet adapts to your needs. Teachers and educators also use Teachlet to generate classroom-ready materials quickly and efficiently.
            </p>
          </div>

          <div className="rounded-xl border border-border bg-card p-6 space-y-3">
            <div className="flex items-center gap-2 font-heading font-semibold text-foreground">
              <Target className="w-4 h-4 text-primary" /> Our Mission
            </div>
            <p>
              Our mission is simple: make high-quality learning accessible to every student on the planet. We believe no student should fall behind because they lacked the time, money, or resources to create effective study materials. By harnessing the power of modern AI, Teachlet puts a world-class study assistant in every student's pocket — available 24/7, personalised to their exact material, and affordable for everyone. We are a passionate team of engineers, designers, and educators who are deeply committed to improving educational outcomes through technology. We continually develop and refine the platform based on student feedback, ensuring Teachlet remains the most effective AI study tool available.
            </p>
          </div>

        </div>

        <div className="mt-10 flex flex-wrap gap-3">
          <Link to="/register">
            <Button className="rounded-full bg-primary text-primary-foreground">
              Get Started Free
            </Button>
          </Link>
          <Link to="/contact">
            <Button variant="outline" className="rounded-full">
              Contact Us
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}