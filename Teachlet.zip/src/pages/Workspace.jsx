const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';

import { useUserProfile } from '../hooks/useUserProfile';
import GenerationCard from '../components/workspace/GenerationCard';
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
  BookOpen, Brain, FileText, HelpCircle, FileType, Mic, Image,
  FileCheck, PenTool, Bot, ArrowLeft, Sparkles, Coins, Lock, Youtube, ChevronDown
} from "lucide-react";

const tools = [
  { type: "study_guide", icon: BookOpen, label: "Study Guide", desc: "Chapter reviews, key concepts, definitions", stat: "study_guides_generated" },
  { type: "flashcards", icon: Brain, label: "Flashcards", desc: "Vocabulary, review cards, smart sets", stat: "flashcards_generated" },
  { type: "practice_test", icon: FileText, label: "Practice Test", desc: "Multiple choice, T/F, short answer", stat: "practice_tests_generated" },
  { type: "quiz", icon: HelpCircle, label: "Quiz", desc: "Quick topic and unit quizzes", stat: "quizzes_generated" },
  { type: "summary", icon: FileType, label: "Summary", desc: "Quick & detailed summaries, bullet notes", stat: "summaries_generated" },
  { type: "presentation", icon: Mic, label: "Presentation", desc: "Slides with speaker notes", stat: "presentations_generated" },
  { type: "poster", icon: Image, label: "Poster", desc: "Research posters & infographics", stat: "posters_generated" },
  { type: "project", icon: FileCheck, label: "Project", desc: "Research projects & lab reports", stat: "projects_generated" },
  { type: "essay", icon: PenTool, label: "Essay", desc: "Outlines, drafts, bibliographies", stat: "essays_generated" },
];

const promptMap = {
  study_guide: `Create a comprehensive, well-structured study guide using rich markdown. Follow this exact format:

# 📚 [MAIN TOPIC TITLE — largest, most prominent]

---

## 🌱 [First Topic / Section Name]

**What it is:**
Write the main explanation here in simple, clear sentences. Keep it direct so students understand it easily.

### 🧠 Key Ideas
- **Key Idea 1** — short, simple explanation
- **Key Idea 2** — short, simple explanation
- **Key Idea 3** — short, simple explanation

### 📚 Examples
> **Example 1:** Write a simple, concrete example here.

> **Example 2:** Another clear example here.

### 🖼️ Visual Concept Questions
- "Describe: [concept from this section] — what is happening?"
- "Explain: [a diagram or process from this section]"

### ⭐ Key Takeaways
1. Most important point from this section
2. Second most important point
3. Third most important point

---

## 🌱 [Second Topic / Section Name]
(repeat the same pattern above)

---

## ⚠️ Common Mistakes to Avoid
- Mistake 1 and why students get it wrong
- Mistake 2 and how to remember it correctly

## 💡 Exam Tips
- Tip 1
- Tip 2

## 🏆 Final Summary
Write a 3-5 sentence overview of the entire topic.

Use **bold** for critical terms. Use > blockquotes for examples. Use emojis for each section heading. Make it genuinely useful for studying. The main title must be the largest text.`,

  flashcards: `Create exactly 15 flashcards for studying this material.
Return ONLY valid JSON in this exact format:
{"flashcards": [{"front": "question or term", "back": "answer or definition"}, ...]}
Make questions specific and answers concise. Cover all key topics from the material.`,

  practice_test: `Create a practice test with 10 questions.
Return ONLY valid JSON in this exact format:
{"questions": [
  {"type": "multiple_choice", "question": "...", "options": ["A. ...", "B. ...", "C. ...", "D. ..."], "answer": "A", "explanation": "..."},
  {"type": "true_false", "question": "...", "answer": "True", "explanation": "..."},
  {"type": "short_answer", "question": "...", "answer": "...", "explanation": "..."}
]}
Include at least 5 multiple_choice, 2 true_false, and 3 short_answer. Make it challenging but fair.`,

  quiz: `Create an 8-question multiple choice quiz.
Return ONLY valid JSON in this exact format:
{"questions": [{"question": "...", "options": ["A. ...", "B. ...", "C. ...", "D. ..."], "correct_index": 0, "explanation": "..."}]}
correct_index is 0-based (0=A, 1=B, 2=C, 3=D). Make questions test key understanding.`,

  summary: `Create a thorough, well-structured summary. Use markdown formatting:

# 📋 Summary: [Topic]

## 🔍 Overview
2-3 sentence quick overview

## 📌 Main Points
### Topic 1
- Key point
- Key point

### Topic 2
- Key point

## 🏆 Key Takeaways
1. Most important takeaway
2. Second takeaway
3. Third takeaway

## 📊 Important Facts & Figures
| Fact | Detail |
|------|--------|

Make it comprehensive yet scannable.`,

  presentation: `Create a professional presentation with 10-12 slides structured like Google Slides.
Return ONLY valid JSON in this exact format:
{"slides": [
  {"slide_number": 1, "layout": "title", "title": "Main Topic Title", "subtitle": "Subtitle or course name", "bullets": [], "notes": "Welcome and introduction notes", "emoji": "🎓"},
  {"slide_number": 2, "layout": "intro", "title": "Introduction", "bullets": ["Key background point 1", "Key background point 2", "Why this topic matters"], "notes": "Speaker notes here", "emoji": "📖"},
  {"slide_number": 3, "layout": "content", "title": "Section Title", "bullets": ["Main point", "Supporting detail", "Example or evidence"], "notes": "Speaker notes", "emoji": "💡"},
  ...more content slides...,
  {"slide_number": 11, "layout": "summary", "title": "Key Takeaways", "bullets": ["Most important point 1", "Most important point 2", "Most important point 3"], "notes": "Summarize the main ideas", "emoji": "🏆"},
  {"slide_number": 12, "layout": "conclusion", "title": "Conclusion & Questions", "bullets": ["Final thought", "Call to action or reflection"], "notes": "Thank audience, open for questions", "emoji": "🎯"}
]}
Keep bullet points SHORT (max 8 words each). Each slide should have 3-5 bullets. Include a title slide, intro, 6-8 content slides, summary, and conclusion. Make it classroom-presentation-ready.`,

  poster: `Create a structured research poster for this topic.
Return ONLY valid JSON in this exact format:
{"poster": {
  "title": "Main poster title",
  "subtitle": "Subtitle or course name",
  "sections": [
    {"heading": "🔍 Introduction", "content": "2-3 sentences introducing the topic and its importance.", "type": "text"},
    {"heading": "📊 Key Findings", "content": ["Finding 1 with brief explanation", "Finding 2 with brief explanation", "Finding 3 with brief explanation"], "type": "list"},
    {"heading": "🔬 Methods / Process", "content": "Brief description of the approach or methodology used.", "type": "text"},
    {"heading": "📈 Data & Evidence", "content": ["Data point or statistic 1", "Data point or statistic 2", "Data point or statistic 3"], "type": "list"},
    {"heading": "💡 Discussion", "content": "Analysis and interpretation of findings. What do the results mean?", "type": "text"},
    {"heading": "🏆 Conclusion", "content": "Summary of the most important takeaways and implications.", "type": "text"},
    {"heading": "📚 References", "content": ["Reference 1 in academic format", "Reference 2 in academic format"], "type": "list"}
  ],
  "image_prompts": [
    "A detailed educational diagram showing [specific concept from the topic], clean white background, scientific illustration style",
    "An infographic chart visualizing [key data or process from the topic], colorful, educational"
  ],
  "color_theme": "academic_blue"
}}
Make it academically rigorous, well-organized, and presentation-ready for school projects.`,

  project: `Create a detailed project outline with:
- Project title and objective
- Background and context
- Methodology and approach
- Key sections to cover
- Timeline with milestones
- Expected outcomes
Format as markdown with headers and bullet points.`,

  essay: (gradeLevel = 'High School') => `Write a complete, well-structured academic essay of 1500 to 2000 words based on the provided study material.

Grade Level: ${gradeLevel}
Adjust vocabulary complexity, sentence structure, and analytical depth appropriately for ${gradeLevel} level.

Format using this structure:

# ✍️ [Essay Title]

## Introduction
Write a compelling hook, provide background context, and end with a clear thesis statement. (150-200 words)

## Body Paragraph 1: [Main Argument]
Topic sentence, evidence from the material, analysis, and transition. (250-350 words)

## Body Paragraph 2: [Supporting Evidence]
Topic sentence, evidence from the material, analysis, and transition. (250-350 words)

## Body Paragraph 3: [Further Development or Counter-argument]
Topic sentence, address a counter-argument if applicable, rebuttal, and transition. (250-350 words)

## Body Paragraph 4: [Synthesis or Additional Evidence]
Connect ideas, deepen analysis. (200-300 words)

## Conclusion
Restate thesis in new words, summarize key arguments, and end with a meaningful closing thought. (150-200 words)

## 📚 Bibliography (MLA Format)
List 3-5 relevant references in proper MLA format.

Use information ONLY from the provided study material. Write complete paragraphs — not bullet points. Ensure proper essay flow and transitions between paragraphs.`,
};

export default function Workspace() {
  const { fileId } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { profile, deductCredits } = useUserProfile();
  const [generatingType, setGeneratingType] = useState(null);
  const [gradeLevel, setGradeLevel] = useState('High School');
  const [showGradeSelect, setShowGradeSelect] = useState(false);

  const gradeLevels = ['Middle School', 'High School', 'College / University', 'Graduate Level'];
  const isPremiumOrAdmin = profile?.plan === 'premium';

  const { data: file } = useQuery({
    queryKey: ['file', fileId],
    queryFn: async () => {
      // SECURITY: filter by both id AND created_by_id (via SDK scoping).
      // The Base44 SDK automatically applies created_by_id = current user,
      // so this will return null if the file belongs to another user.
      const files = await db.entities.UploadedFile.filter({ id: fileId });
      return files[0] || null;
    },
  });

  const { data: contents = [] } = useQuery({
    queryKey: ['contents', fileId],
    // SECURITY: only fetch generated content for files owned by this user.
    // If `file` is null (unauthorized), this returns empty.
    queryFn: () => file ? db.entities.GeneratedContent.filter({ file_id: fileId }) : [],
    enabled: !!file,
    initialData: [],
  });

  const isYoutube = file?.file_type === 'youtube';
  const isPremium = profile?.plan === 'premium'; // includes admin via hook override

  const handleGenerate = async (tool) => {
    // YouTube is premium-only
    if (isYoutube && !isPremium) {
      toast.error("YouTube analysis is a Premium feature. Upgrade to unlock it!");
      navigate('/upgrade');
      return;
    }

    const canGenerate = await deductCredits(20, tool.stat);
    if (!canGenerate) {
      toast.error("Not enough credits. Upgrade to Premium for unlimited generations.");
      navigate('/upgrade');
      return;
    }

    setGeneratingType(tool.type);

    const fileUrl = file?.file_url;
    // A URL from our storage (base44 CDN) vs an external URL
    const isStoredFile = fileUrl && (fileUrl.includes('storage') || fileUrl.includes('base44') || !fileUrl.startsWith('http'));

    let sourceContext = '';
    if (isYoutube) {
      sourceContext = `YouTube video URL: ${file.file_url}\nPlease analyze this YouTube video's content, transcript, and educational material.`;
    } else {
      sourceContext = `Study material title: "${file.name}". File type: ${file.file_type}.`;
    }

    const promptTemplate = tool.type === 'essay'
      ? promptMap.essay(gradeLevel)
      : promptMap[tool.type];
    const prompt = `${sourceContext}\n\n${promptTemplate}`;

    const result = await db.integrations.Core.InvokeLLM({
      prompt,
      file_urls: isStoredFile ? [fileUrl] : undefined,
      add_context_from_internet: isYoutube,
    });

    let finalContent = { raw: typeof result === 'string' ? result : JSON.stringify(result), type: tool.type };

    // For posters: generate images from the AI-suggested prompts
    if (tool.type === 'poster') {
      try {
        let posterData = null;
        const rawStr = typeof result === 'string' ? result : JSON.stringify(result);
        const jsonMatch = rawStr.match(/```(?:json)?\s*([\s\S]*?)```/);
        try { posterData = JSON.parse(jsonMatch ? jsonMatch[1] : rawStr); } catch { posterData = null; }

        if (posterData?.poster?.image_prompts?.length > 0) {
          toast.info("Generating poster images...");
          const imageResults = await Promise.all(
            posterData.poster.image_prompts.slice(0, 2).map(imgPrompt =>
              db.integrations.Core.GenerateImage({ prompt: imgPrompt })
                .then(r => r.url).catch(() => null)
            )
          );
          posterData.poster.generated_images = imageResults.filter(Boolean);
          finalContent = { raw: JSON.stringify(posterData), type: tool.type };
        }
      } catch {
        // proceed without images
      }
    }

    await db.entities.GeneratedContent.create({
      file_id: fileId,
      type: tool.type,
      title: `${tool.label} — ${file?.name}`,
      content: JSON.stringify(finalContent),
      status: 'ready',
    });

    queryClient.invalidateQueries({ queryKey: ['contents', fileId] });
    queryClient.invalidateQueries({ queryKey: ['userProfile'] });
    setGeneratingType(null);
    toast.success(`${tool.label} generated! Click to view it.`);
  };

  if (!file) {
    return (
      <div className="p-6 text-center mt-20">
        <p className="text-muted-foreground">Loading workspace...</p>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <Link to="/files">
          <Button variant="ghost" size="icon" className="rounded-full">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            {isYoutube && <Youtube className="w-4 h-4 text-red-500 flex-shrink-0" />}
            <h1 className="text-xl sm:text-2xl font-display font-bold truncate">{file.name}</h1>
          </div>
          <p className="text-xs text-muted-foreground flex items-center gap-2">
            {file.file_type?.toUpperCase()}
            {isYoutube && !isPremium && (
              <span className="inline-flex items-center gap-1 text-amber-600 font-medium">
                <Lock className="w-3 h-3" /> Premium Required
              </span>
            )}
            {!isYoutube && (
              <span className="flex items-center gap-1">
                <Coins className="w-3 h-3" />
                {isPremium ? '∞' : (profile?.credits_remaining ?? 200)} credits
              </span>
            )}
          </p>
        </div>
      </div>

      {/* YouTube premium gate banner */}
      {isYoutube && !isPremium && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200 dark:bg-amber-950/20 dark:border-amber-800 flex items-center justify-between gap-4"
        >
          <div className="flex items-center gap-3">
            <Youtube className="w-6 h-6 text-red-500 flex-shrink-0" />
            <div>
              <p className="font-semibold text-sm">YouTube Analysis is a Premium Feature</p>
              <p className="text-xs text-muted-foreground">Upgrade to analyze YouTube videos and generate study materials from them.</p>
            </div>
          </div>
          <Link to="/upgrade">
            <Button size="sm" className="rounded-full bg-primary text-primary-foreground flex-shrink-0">
              Upgrade
            </Button>
          </Link>
        </motion.div>
      )}

      {/* Generated content */}
      {contents.length > 0 && (
        <div className="mt-6 mb-8">
          <h2 className="font-heading font-semibold text-sm text-muted-foreground mb-3">Generated Content</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {contents.map((c) => (
              <Link key={c.id} to={`/view/${c.id}`}>
                <div className="p-3 rounded-xl bg-card border border-border hover:border-primary/30 transition-colors flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-primary" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{c.title}</p>
                    <p className="text-xs text-muted-foreground capitalize">{c.type?.replace(/_/g, ' ')}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Generation hub */}
      <div className="mt-6">
        <div className="flex items-center justify-between mb-1 flex-wrap gap-2">
          <h2 className="font-heading font-semibold">What would you like Teachlet AI to create?</h2>
          {/* Grade level selector — relevant for essay */}
          <div className="relative">
            <button
              onClick={() => setShowGradeSelect(v => !v)}
              className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full border border-border bg-card hover:bg-muted transition-colors"
            >
              🎓 {gradeLevel} <ChevronDown className="w-3 h-3" />
            </button>
            {showGradeSelect && (
              <div className="absolute right-0 top-9 z-20 bg-card border border-border rounded-xl shadow-lg py-1 w-52">
                {gradeLevels.map(lvl => (
                  <button
                    key={lvl}
                    onClick={() => { setGradeLevel(lvl); setShowGradeSelect(false); }}
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-muted transition-colors ${gradeLevel === lvl ? 'text-primary font-semibold' : ''}`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
        <p className="text-xs text-muted-foreground mb-4">
          {isPremium ? 'Unlimited generations with Premium' : 'Each generation costs 20 credits'}
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {tools.map((tool) => (
            <GenerationCard
              key={tool.type}
              icon={isYoutube && !isPremium ? Lock : tool.icon}
              label={tool.label}
              desc={tool.type === 'essay'
                ? `${gradeLevel} level · 1500–2000 words`
                : (isYoutube && !isPremium ? 'Premium required for YouTube' : tool.desc)}
              generating={generatingType === tool.type}
              disabled={generatingType !== null && generatingType !== tool.type}
              onClick={() => handleGenerate(tool)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}