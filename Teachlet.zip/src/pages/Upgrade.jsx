import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Check, Gem, Sparkles, ArrowLeft, Loader2, AlertTriangle, CheckCircle2, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";
import { useUserProfile } from '../hooks/useUserProfile';

import { toast } from "sonner";

const features = [
  "Unlimited Credits",
  "Unlimited AI Generations",
  "Unlimited File Uploads",
  "Unlimited AI Tutor Conversations",
  "Faster Processing & Priority Servers",
  "No Ads & Premium Themes",
  "AI Exam Predictor",
  "AI Research Assistant",
  "AI Study Planner Pro",
  "Bulk AI Generation",
  "Advanced Analytics",
  "Premium AI Models",
  "100MB Upload Limit",
  "Early Access Features",
];

// IMPORTANT: Replace this with your actual Stripe Payment Link URL
const STRIPE_PAYMENT_LINK = "https://buy.stripe.com/test_fZu7sDcKCcuI7CY5ZH6oo01";

export default function Upgrade() {
  const { profile, updateProfile } = useUserProfile();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const isPremium = profile?.plan === 'premium';
  const subStatus = profile?.subscription_status || 'none';

  // Payment verification after Stripe redirect
  // We detect the return URL but do NOT auto-grant premium from URL params alone.
  // Instead we show a message telling the user to contact support or wait for webhook.
  const [showPaymentReturn, setShowPaymentReturn] = useState(false);
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('success') === 'true') {
      setShowPaymentReturn(true);
      // Clean the URL so a refresh doesn't re-trigger
      navigate('/upgrade', { replace: true });
    }
  }, []);

  const handleUpgrade = async () => {
    if (STRIPE_PAYMENT_LINK.includes('YOUR_PAYMENT_LINK')) {
      setError('Stripe Payment Link not configured yet. Please add your Stripe link.');
      return;
    }
    setError('');
    setLoading(true);
    const returnUrl = `${window.location.origin}/upgrade?success=true`;
    const stripeUrl = `${STRIPE_PAYMENT_LINK}?success_url=${encodeURIComponent(returnUrl)}`;
    window.location.href = stripeUrl;
  };

  const handleManageSubscription = () => {
    toast.info("To manage your subscription, please contact support.");
  };

  if (showPaymentReturn && !isPremium) {
    return (
      <div className="p-4 sm:p-6 lg:p-8 max-w-2xl mx-auto text-center mt-10">
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
        </div>
        <h1 className="text-2xl font-display font-bold mb-2">Processing your payment…</h1>
        <p className="text-muted-foreground mb-4">
          Your payment is being verified. Premium access will be activated automatically within a few minutes once confirmed by Stripe.
        </p>
        <p className="text-sm text-muted-foreground mb-6">
          If you're not upgraded within 5 minutes, please contact support with your payment receipt.
        </p>
        <Link to="/dashboard">
          <Button className="rounded-full bg-primary text-primary-foreground">
            Back to Dashboard
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-2xl mx-auto">
      <Link to="/dashboard">
        <Button variant="ghost" size="sm" className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-1" /> Back
        </Button>
      </Link>

      {isPremium ? (
        <motion.div
          className="rounded-2xl bg-card border border-primary/20 p-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-display font-bold mb-2">You're on Premium!</h1>
          <p className="text-muted-foreground mb-6">
            {subStatus === 'active' && 'Your subscription is active. Enjoy unlimited access.'}
            {subStatus === 'trialing' && 'Your trial is active. Enjoy unlimited access.'}
            {subStatus === 'canceled' && 'Your subscription has been canceled. Access continues until the end of the billing period.'}
            {subStatus === 'past_due' && 'Your payment is past due. Please update your payment method.'}
            {subStatus === 'none' && 'Your premium access is active.'}
          </p>

          {subStatus === 'past_due' && (
            <div className="mb-4 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              Payment failed. Please update your billing information to keep your Premium access.
            </div>
          )}

          {error && (
            <div className="mb-4 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
              {error}
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              onClick={handleManageSubscription}
              disabled={loading}
              variant="outline"
              className="rounded-full"
            >
              {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ExternalLink className="w-4 h-4 mr-2" />}
              Manage Subscription
            </Button>
            <Link to="/dashboard">
              <Button className="rounded-full bg-primary text-primary-foreground">
                Go to Dashboard
              </Button>
            </Link>
          </div>
        </motion.div>
      ) : (
        <motion.div
          className="rounded-2xl bg-foreground text-background p-8 sm:p-10 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold mb-4">
            <Gem className="w-3 h-3" /> Premium
          </div>
          <h1 className="text-3xl font-display font-bold">Upgrade to Premium</h1>
          <p className="text-background/60 mt-2">Unlock the full power of Teachlet AI</p>

          <div className="mt-6 flex items-baseline justify-center gap-1">
            <span className="text-5xl font-display font-bold">$6.99</span>
            <span className="text-background/60">/month</span>
          </div>

          <ul className="mt-8 space-y-3 text-left max-w-sm mx-auto">
            {features.map((f, i) => (
              <li key={i} className="flex items-center gap-2.5 text-sm">
                <Check className="w-4 h-4 text-primary flex-shrink-0" />
                {f}
              </li>
            ))}
          </ul>

          {error && (
            <div className="mt-6 p-3 rounded-lg bg-destructive/20 border border-destructive/30 text-destructive text-sm text-left flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              {error}
            </div>
          )}

          <Button
            className="mt-8 bg-primary text-primary-foreground hover:bg-primary/90 rounded-full h-12 px-10 font-semibold text-base shadow-lg shadow-primary/25"
            onClick={handleUpgrade}
            disabled={loading}
          >
            {loading ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Processing...</>
            ) : (
              <><Sparkles className="w-4 h-4 mr-2" />Get Premium Now</>
            )}
          </Button>
          <p className="text-xs text-background/40 mt-3">Cancel anytime. No hidden fees. Secured by Stripe.</p>
        </motion.div>
      )}
    </div>
  );
}