import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import { ThemeProvider } from '@/lib/ThemeContext';

import Landing from '@/pages/Landing';
import About from '@/pages/About';
import Contact from '@/pages/Contact';
import Dashboard from '@/pages/Dashboard';
import Upload from '@/pages/Upload';
import Files from '@/pages/Files';
import Workspace from '@/pages/Workspace';
import ContentView from '@/pages/ContentView';
import ContentList from '@/pages/ContentList';
import AITutor from '@/pages/AITutor';
import StudyPlanner from '@/pages/StudyPlanner';
import ExamPrep from '@/pages/ExamPrep';
import Analytics from '@/pages/Analytics';
import Settings from '@/pages/Settings';
import Upgrade from '@/pages/Upgrade';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (authError?.type === 'user_not_registered') {
    return <UserNotRegisteredError />;
  }

  return (
    <Routes>
      {/* Public routes — always accessible */}
      <Route path="/" element={<Landing />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />

      {/* Dashboard routes with sidebar */}
      <Route element={<DashboardLayout />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/upload" element={<Upload />} />
        <Route path="/files" element={<Files />} />
        <Route path="/workspace/:fileId" element={<Workspace />} />
        <Route path="/view/:contentId" element={<ContentView />} />
        <Route path="/study-guides" element={<ContentList />} />
        <Route path="/flashcards" element={<ContentList />} />
        <Route path="/practice-tests" element={<ContentList />} />
        <Route path="/quizzes" element={<ContentList />} />
        <Route path="/summaries" element={<ContentList />} />
        <Route path="/presentations" element={<ContentList />} />
        <Route path="/posters" element={<ContentList />} />
        <Route path="/projects" element={<ContentList />} />
        <Route path="/essays" element={<ContentList />} />
        <Route path="/ai-tutor" element={<AITutor />} />
        <Route path="/study-planner" element={<StudyPlanner />} />
        <Route path="/exam-prep" element={<ExamPrep />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/upgrade" element={<Upgrade />} />
      </Route>

      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <AuthenticatedApp />
          </Router>
          <Toaster />
        </QueryClientProvider>
      </AuthProvider>
    </ThemeProvider>
  )
}

export default App